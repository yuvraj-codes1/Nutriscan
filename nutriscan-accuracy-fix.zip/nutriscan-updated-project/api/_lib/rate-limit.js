// ─────────────────────────────────────────────────────────────────────────
// Rate limiting (OWASP API4:2023 — Unrestricted Resource Consumption)
//
// This app calls a paid, latency-heavy vision model on every request, so
// unrestricted access is both a cost and an availability risk (one script
// hammering /api/analyse can exhaust the NVIDIA quota for every real user).
//
// IMPORTANT — serverless caveat:
// Vercel functions are stateless and may run as multiple concurrent
// instances, so this in-memory limiter is a *best-effort* per-instance
// guard, not a globally-consistent one. It still stops the common cases
// (a single client hammering the endpoint, a runaway loop, a scraper) and
// costs nothing to run. For strict, multi-instance-consistent limiting in
// production, swap the store below for a shared backend such as
// Upstash Redis / Vercel KV — the limiter logic (windows, keys, headers)
// does not need to change, only `store` does.
// ─────────────────────────────────────────────────────────────────────────

"use strict";

/**
 * @typedef {Object} RateLimitResult
 * @property {boolean} allowed
 * @property {number} limit
 * @property {number} remaining
 * @property {number} resetSeconds - seconds until the window resets
 */

// key -> { count, windowStart }
const buckets = new Map();

// Periodically sweep expired buckets so the Map doesn't grow unbounded
// across the lifetime of a warm serverless instance.
const SWEEP_INTERVAL_MS = 5 * 60 * 1000;
let lastSweep = Date.now();
function sweepIfNeeded(now) {
  if (now - lastSweep < SWEEP_INTERVAL_MS) return;
  lastSweep = now;
  for (const [key, bucket] of buckets) {
    if (now - bucket.windowStart > 24 * 60 * 60 * 1000) buckets.delete(key);
  }
}

/**
 * Fixed-window rate limiter.
 * @param {string} key - unique identifier for the caller (IP, user id, or combo)
 * @param {number} limit - max requests allowed per window
 * @param {number} windowMs - window size in milliseconds
 * @returns {RateLimitResult}
 */
function checkRateLimit(key, limit, windowMs) {
  const now = Date.now();
  sweepIfNeeded(now);

  let bucket = buckets.get(key);
  if (!bucket || now - bucket.windowStart >= windowMs) {
    bucket = { count: 0, windowStart: now };
    buckets.set(key, bucket);
  }

  bucket.count += 1;
  const resetSeconds = Math.max(1, Math.ceil((bucket.windowStart + windowMs - now) / 1000));

  return {
    allowed: bucket.count <= limit,
    limit,
    remaining: Math.max(0, limit - bucket.count),
    resetSeconds
  };
}

// ---------------------------------------------------------------------------
// Defaults tuned for a single-endpoint, vision-model-backed API:
//   - Per-IP: coarse guard against anonymous abuse / scraping.
//   - Per-user (if/when auth exists): tighter, fair-use guard per identity.
// These are intentionally conservative for an app that shells out to a
// paid model per call; adjust to your real traffic/cost profile.
// ---------------------------------------------------------------------------
const DEFAULT_LIMITS = {
  ip: { limit: 20, windowMs: 60 * 1000 },       // 20 req/min per IP
  user: { limit: 10, windowMs: 60 * 1000 },     // 10 req/min per authenticated user
  ipBurst: { limit: 200, windowMs: 60 * 60 * 1000 } // 200 req/hour per IP (hard ceiling)
};

/**
 * Extract the best-effort client IP from a Vercel/Node request. Vercel
 * terminates TLS and sets x-forwarded-for; we take the left-most (original
 * client) entry and never trust it for anything beyond rate-limit keying.
 */
function getClientIp(req) {
  const xff = req.headers["x-forwarded-for"];
  if (typeof xff === "string" && xff.length) {
    return xff.split(",")[0].trim();
  }
  return req.socket?.remoteAddress || req.connection?.remoteAddress || "unknown";
}

/**
 * Apply IP-based (and, if a userId is supplied, user-based) rate limiting.
 * Sends standard rate-limit headers on every response and a 429 with
 * Retry-After when the caller is over the limit. Returns true if the
 * request was blocked (caller should stop processing).
 *
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 * @param {{ userId?: string, limits?: typeof DEFAULT_LIMITS }} [opts]
 * @returns {boolean} blocked
 */
function enforceRateLimit(req, res, opts = {}) {
  const limits = opts.limits || DEFAULT_LIMITS;
  const ip = getClientIp(req);

  // Per-minute IP check
  const ipResult = checkRateLimit(`ip:${ip}`, limits.ip.limit, limits.ip.windowMs);
  // Per-hour IP ceiling, independent window, catches sustained low-and-slow abuse
  const ipBurstResult = checkRateLimit(`ipburst:${ip}`, limits.ipBurst.limit, limits.ipBurst.windowMs);

  // Per-user check, only meaningful once the app has authenticated users.
  // Wired up here so it activates automatically the moment req.userId (or
  // a verified session/JWT subject) is available upstream — see analyse.js.
  let userResult = null;
  if (opts.userId) {
    userResult = checkRateLimit(`user:${opts.userId}`, limits.user.limit, limits.user.windowMs);
  }

  const worst = [ipResult, ipBurstResult, userResult].filter(Boolean)
    .sort((a, b) => a.remaining - b.remaining)[0];

  res.setHeader("X-RateLimit-Limit", String(worst.limit));
  res.setHeader("X-RateLimit-Remaining", String(worst.remaining));
  res.setHeader("X-RateLimit-Reset", String(worst.resetSeconds));

  const blocked = !ipResult.allowed || !ipBurstResult.allowed || (userResult && !userResult.allowed);
  if (blocked) {
    const blockedResult = !ipResult.allowed ? ipResult : (!ipBurstResult.allowed ? ipBurstResult : userResult);
    res.setHeader("Retry-After", String(blockedResult.resetSeconds));
    res.status(429).json({
      error: "Too many requests. Please slow down and try again shortly.",
      retryAfterSeconds: blockedResult.resetSeconds
    });
    return true;
  }
  return false;
}

module.exports = { enforceRateLimit, checkRateLimit, getClientIp, DEFAULT_LIMITS };
