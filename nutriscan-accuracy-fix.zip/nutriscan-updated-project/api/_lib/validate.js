// ─────────────────────────────────────────────────────────────────────────
// Input validation & sanitization (OWASP API3:2023 — Broken Object Property
// Level Authorization / Excessive Data Exposure, and general injection
// hardening).
//
// Rules followed here:
//   - Whitelist, don't blacklist: only known fields are accepted; anything
//     else in the request body is rejected outright (prevents mass-
//     assignment / parameter-pollution style surprises if the handler is
//     later extended to spread req.body somewhere).
//   - Every field gets an explicit type check, format check, and length
//     limit before it touches any business logic.
//   - Validation failures return a generic, non-revealing 400 message —
//     detail goes to server logs only, not to the client.
// ─────────────────────────────────────────────────────────────────────────

"use strict";

// Base64 body size limits. The frontend compresses images to <=1536px at
// 0.88 quality before sending, which in practice lands well under 2MB of
// base64 text; 8MB gives generous headroom for larger/denser photos while
// still bounding memory and the cost of a wasted model call on garbage
// input. Vercel's default body size limit (4.5MB on Hobby) will often
// reject oversized payloads before this even runs, but we don't rely on
// that alone since limits vary by plan/config.
const MAX_IMAGE_BASE64_CHARS = 8 * 1024 * 1024; // ~8MB of base64 text
const MIN_IMAGE_BASE64_CHARS = 100; // guards against empty/near-empty strings

// Matches a raw base64 payload OR a data: URL prefix, either of which the
// frontend might send. We normalize to raw base64 before returning.
const DATA_URL_PREFIX = /^data:image\/(jpeg|jpg|png|webp);base64,/i;
// Strict base64 alphabet check (RFC 4648), rejects anything containing
// script tags, SQL fragments, path traversal sequences, etc. by construction.
const BASE64_CHARS_RE = /^[A-Za-z0-9+/]+={0,2}$/;

class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = "ValidationError";
    this.status = 400;
  }
}

/**
 * Validate & sanitize the body of POST /api/analyse.
 * Throws ValidationError with a safe, user-facing message on any problem.
 * Returns a cleaned { image } object — the only shape downstream code
 * should ever see.
 */
function validateAnalyseRequest(body) {
  if (body === null || typeof body !== "object" || Array.isArray(body)) {
    throw new ValidationError("Request body must be a JSON object.");
  }

  // Whitelist enforcement: reject any unexpected top-level fields instead
  // of silently ignoring them. This surfaces integration bugs early and
  // stops unused fields from ever being trusted later by mistake.
  const allowedKeys = new Set(["image"]);
  const unexpectedKeys = Object.keys(body).filter((k) => !allowedKeys.has(k));
  if (unexpectedKeys.length) {
    throw new ValidationError(
      `Unexpected field(s) in request: ${unexpectedKeys.slice(0, 5).join(", ")}.`
    );
  }

  const { image } = body;

  if (typeof image !== "string") {
    throw new ValidationError("Field 'image' is required and must be a string.");
  }

  let raw = image.trim();
  if (!raw) {
    throw new ValidationError("Field 'image' must not be empty.");
  }

  // Strip an accepted data: URL prefix if present; reject any other prefix
  // (e.g. data:text/html, javascript:) outright rather than trying to
  // "clean" it — ambiguous input is refused, not guessed at.
  const looksLikeDataUrl = raw.startsWith("data:");
  if (looksLikeDataUrl) {
    if (!DATA_URL_PREFIX.test(raw)) {
      throw new ValidationError("Unsupported image format. Use JPEG, PNG, or WebP.");
    }
    raw = raw.replace(DATA_URL_PREFIX, "");
  }

  if (raw.length < MIN_IMAGE_BASE64_CHARS) {
    throw new ValidationError("Image data is too small to be a valid photo.");
  }
  if (raw.length > MAX_IMAGE_BASE64_CHARS) {
    throw new ValidationError("Image is too large. Please use a smaller photo.");
  }

  if (!BASE64_CHARS_RE.test(raw)) {
    throw new ValidationError("Image data is not valid base64.");
  }

  // Defense in depth: confirm it actually decodes and re-encodes to the
  // same string modulo padding — catches malformed/truncated base64 that
  // technically matches the character-set regex but isn't decodable.
  let decoded;
  try {
    decoded = Buffer.from(raw, "base64");
  } catch {
    throw new ValidationError("Image data could not be decoded.");
  }
  if (!decoded || decoded.length === 0) {
    throw new ValidationError("Image data could not be decoded.");
  }

  // Sanity-check magic bytes for common formats so we're not shipping
  // arbitrary binary blobs to a paid third-party API. This is not a full
  // file-type sniffer, just enough to reject obvious non-images cheaply.
  const isJpeg = decoded[0] === 0xff && decoded[1] === 0xd8;
  const isPng = decoded[0] === 0x89 && decoded[1] === 0x50 && decoded[2] === 0x4e && decoded[3] === 0x47;
  const isWebp = decoded.length > 12 && decoded.toString("ascii", 0, 4) === "RIFF" && decoded.toString("ascii", 8, 12) === "WEBP";
  if (!isJpeg && !isPng && !isWebp) {
    throw new ValidationError("Unsupported image format. Use JPEG, PNG, or WebP.");
  }

  return { image: raw };
}

module.exports = { validateAnalyseRequest, ValidationError };
