// ─────────────────────────────────────────────────────────────────────────
// Common Ingredients Nutrition Database
//
// Unlike indian-food-db.js and world-food-db.js (which cover *named finished
// dishes* — "butter chicken", "pad thai"), this file covers the raw/simply-
// prepared *building-block ingredients* that the VLM's component breakdown
// produces for home-cooked meals that don't match a single named dish
// (e.g. a photo gets decomposed into "grilled chicken thigh", "steamed
// broccoli", "white rice" rather than a single dish name).
//
// This is the layer that was thinnest before — the two dish DBs are mostly
// finished recipes, so any home-cooked combination the VLM couldn't name
// as a single dish fell straight through to raw per-ingredient VLM guessing
// (the least reliable tier). This file plugs that gap with USDA-grounded
// values for the ingredients most likely to appear in home-cooked photos:
// proteins, dairy/cheese, vegetables, fruits, grains/starches, legumes,
// nuts, condiments/sauces, and basic prepared forms (grilled, roasted,
// fried, boiled).
//
// Values are per 100g, as-prepared (cooked, where cooking is typical) so
// they line up with visual gram estimates from a plate photo. Sourced from
// USDA FoodData Central (SR Legacy / Foundation Foods) and cross-checked
// against multiple independent nutrition references.
//
// Checked in analyse.js AFTER indian-food-db.js and world-food-db.js (so a
// named dish like "palak paneer" or "pad thai" still wins over a generic
// ingredient match) and BEFORE the USDA API lookup / Open Food Facts / VLM
// fallback tiers.
// ─────────────────────────────────────────────────────────────────────────

// Each entry: kcal, carbs, protein, fat, fiber, sugars, satFat — all per 100g.
const INGREDIENTS_DB = [
  // ---- Beef ----
  { keys: ["ground beef 80", "ground beef", "beef mince", "minced beef", "hamburger meat"], kcal: 270, carbs: 0, protein: 26, fat: 18, fiber: 0, sugars: 0, satFat: 7 },
  { keys: ["lean ground beef", "ground beef 93", "extra lean ground beef"], kcal: 195, carbs: 0, protein: 26, fat: 10, fiber: 0, sugars: 0, satFat: 4 },
  { keys: ["beef sirloin", "sirloin steak", "flank steak", "beef flank"], kcal: 205, carbs: 0, protein: 28, fat: 10, fiber: 0, sugars: 0, satFat: 4 },
  { keys: ["beef short rib", "short ribs", "braised beef"], kcal: 295, carbs: 0, protein: 24, fat: 22, fiber: 0, sugars: 0, satFat: 9 },
  { keys: ["beef brisket", "brisket"], kcal: 250, carbs: 0, protein: 26, fat: 16, fiber: 0, sugars: 0, satFat: 6.5 },
  { keys: ["beef stew meat", "beef chunks", "stewing beef"], kcal: 215, carbs: 0, protein: 27, fat: 11, fiber: 0, sugars: 0, satFat: 4.3 },
  { keys: ["roast beef"], kcal: 200, carbs: 0, protein: 29, fat: 8.5, fiber: 0, sugars: 0, satFat: 3.3 },

  // ---- Pork ----
  { keys: ["pork chop", "grilled pork chop"], kcal: 231, carbs: 0, protein: 27, fat: 13, fiber: 0, sugars: 0, satFat: 4.5 },
  { keys: ["pork tenderloin", "pork loin"], kcal: 143, carbs: 0, protein: 26, fat: 3.5, fiber: 0, sugars: 0, satFat: 1.2 },
  { keys: ["pulled pork"], kcal: 240, carbs: 4, protein: 23, fat: 15, fiber: 0.3, sugars: 3, satFat: 5.5 },
  { keys: ["pork belly"], kcal: 395, carbs: 0, protein: 15, fat: 37, fiber: 0, sugars: 0, satFat: 13.5 },
  { keys: ["ground pork", "pork mince"], kcal: 260, carbs: 0, protein: 25, fat: 17, fiber: 0, sugars: 0, satFat: 6 },
  { keys: ["ham", "sliced ham"], kcal: 145, carbs: 1.5, protein: 21, fat: 5.5, fiber: 0, sugars: 1.5, satFat: 1.8 },
  { keys: ["prosciutto"], kcal: 195, carbs: 0.5, protein: 28, fat: 8.5, fiber: 0, sugars: 0.3, satFat: 3 },
  { keys: ["chorizo"], kcal: 335, carbs: 2, protein: 19, fat: 28, fiber: 0.5, sugars: 0.5, satFat: 10.5 },
  { keys: ["pepperoni"], kcal: 460, carbs: 2, protein: 19, fat: 41, fiber: 0, sugars: 0, satFat: 15 },
  { keys: ["salami"], kcal: 375, carbs: 2, protein: 20, fat: 32, fiber: 0, sugars: 0.5, satFat: 11.5 },
  { keys: ["hot dog", "frankfurter"], kcal: 290, carbs: 4, protein: 11, fat: 26, fiber: 0, sugars: 2, satFat: 9.5 },

  // ---- Poultry ----
  { keys: ["chicken thigh", "grilled chicken thigh", "roasted chicken thigh"], kcal: 209, carbs: 0, protein: 26, fat: 11, fiber: 0, sugars: 0, satFat: 3 },
  { keys: ["chicken drumstick", "grilled chicken drumstick"], kcal: 172, carbs: 0, protein: 28, fat: 6, fiber: 0, sugars: 0, satFat: 1.6 },
  { keys: ["chicken wing", "buffalo wings", "chicken wings"], kcal: 290, carbs: 0, protein: 27, fat: 19, fiber: 0, sugars: 0, satFat: 5.5 },
  { keys: ["shredded chicken", "pulled chicken", "chicken breast shredded"], kcal: 165, carbs: 0, protein: 31, fat: 3.6, fiber: 0, sugars: 0, satFat: 1 },
  { keys: ["ground turkey", "turkey mince"], kcal: 203, carbs: 0, protein: 27, fat: 10, fiber: 0, sugars: 0, satFat: 2.7 },
  { keys: ["turkey breast", "sliced turkey", "deli turkey"], kcal: 135, carbs: 1, protein: 30, fat: 1, fiber: 0, sugars: 0.5, satFat: 0.3 },
  { keys: ["duck breast", "roast duck"], kcal: 200, carbs: 0, protein: 23, fat: 11.5, fiber: 0, sugars: 0, satFat: 4 },

  // ---- Fish / seafood ----
  { keys: ["shrimp", "prawns", "grilled shrimp"], kcal: 105, carbs: 1, protein: 24, fat: 1.2, fiber: 0, sugars: 0, satFat: 0.3 },
  { keys: ["tuna steak", "grilled tuna", "seared tuna"], kcal: 130, carbs: 0, protein: 28, fat: 1, fiber: 0, sugars: 0, satFat: 0.3 },
  { keys: ["canned tuna in water", "tuna in water"], kcal: 116, carbs: 0, protein: 26, fat: 0.8, fiber: 0, sugars: 0, satFat: 0.2 },
  { keys: ["canned tuna in oil", "tuna in oil"], kcal: 190, carbs: 0, protein: 25, fat: 9, fiber: 0, sugars: 0, satFat: 1.6 },
  { keys: ["cod fillet", "baked cod", "grilled cod", "cod"], kcal: 105, carbs: 0, protein: 23, fat: 0.9, fiber: 0, sugars: 0, satFat: 0.2 },
  { keys: ["tilapia"], kcal: 128, carbs: 0, protein: 26, fat: 2.7, fiber: 0, sugars: 0, satFat: 0.9 },
  { keys: ["crab meat", "crab"], kcal: 97, carbs: 0, protein: 19, fat: 1.5, fiber: 0, sugars: 0, satFat: 0.2 },
  { keys: ["scallops", "seared scallops"], kcal: 111, carbs: 3, protein: 21, fat: 0.8, fiber: 0, sugars: 0, satFat: 0.1 },
  { keys: ["mussels"], kcal: 172, carbs: 7, protein: 24, fat: 4.5, fiber: 0, sugars: 0, satFat: 0.9 },
  { keys: ["calamari", "fried calamari", "squid"], kcal: 175, carbs: 8, protein: 16, fat: 8, fiber: 0.3, sugars: 0, satFat: 1.5 },
  { keys: ["smoked salmon"], kcal: 117, carbs: 0, protein: 18, fat: 4.3, fiber: 0, sugars: 0, satFat: 0.9 },

  // ---- Eggs / dairy / cheese ----
  { keys: ["poached egg"], kcal: 143, carbs: 0.6, protein: 12.5, fat: 9.5, fiber: 0, sugars: 0.6, satFat: 3 },
  { keys: ["egg white", "egg whites"], kcal: 52, carbs: 0.7, protein: 11, fat: 0.2, fiber: 0, sugars: 0.7, satFat: 0 },
  { keys: ["feta cheese", "feta"], kcal: 264, carbs: 4, protein: 14.2, fat: 21, fiber: 0, sugars: 4, satFat: 15 },
  { keys: ["parmesan cheese", "parmesan", "grated parmesan"], kcal: 420, carbs: 3.2, protein: 38, fat: 29, fiber: 0, sugars: 0.9, satFat: 19 },
  { keys: ["cream cheese"], kcal: 340, carbs: 4, protein: 6, fat: 34, fiber: 0, sugars: 3.2, satFat: 19 },
  { keys: ["goat cheese"], kcal: 265, carbs: 0.1, protein: 22, fat: 21, fiber: 0, sugars: 0.1, satFat: 14.7 },
  { keys: ["blue cheese"], kcal: 355, carbs: 2.3, protein: 21, fat: 29, fiber: 0, sugars: 0.5, satFat: 18.7 },
  { keys: ["swiss cheese"], kcal: 380, carbs: 5.4, protein: 27, fat: 28, fiber: 0, sugars: 1, satFat: 18 },
  { keys: ["provolone"], kcal: 350, carbs: 2, protein: 25.6, fat: 27, fiber: 0, sugars: 0.5, satFat: 17 },
  { keys: ["ricotta cheese", "ricotta"], kcal: 174, carbs: 3, protein: 11.3, fat: 13, fiber: 0, sugars: 0.3, satFat: 8.3 },
  { keys: ["burrata"], kcal: 330, carbs: 2, protein: 15, fat: 28, fiber: 0, sugars: 2, satFat: 18 },
  { keys: ["halloumi"], kcal: 320, carbs: 2, protein: 22, fat: 25, fiber: 0, sugars: 1, satFat: 17 },
  { keys: ["cottage cheese"], kcal: 98, carbs: 3.4, protein: 11, fat: 4.3, fiber: 0, sugars: 2.7, satFat: 2.7 },
  { keys: ["greek yogurt", "greek yoghurt"], kcal: 59, carbs: 3.6, protein: 10, fat: 0.4, fiber: 0, sugars: 3.2, satFat: 0.1 },
  { keys: ["plain yogurt", "plain yoghurt", "natural yogurt"], kcal: 61, carbs: 4.7, protein: 3.5, fat: 3.3, fiber: 0, sugars: 4.7, satFat: 2.1 },
  { keys: ["whole milk"], kcal: 61, carbs: 4.8, protein: 3.2, fat: 3.3, fiber: 0, sugars: 5.1, satFat: 1.9 },
  { keys: ["heavy cream", "double cream"], kcal: 340, carbs: 2.8, protein: 2.1, fat: 36, fiber: 0, sugars: 2.9, satFat: 22.5 },
  { keys: ["sour cream"], kcal: 198, carbs: 4.6, protein: 2.4, fat: 19.4, fiber: 0, sugars: 3.8, satFat: 12.1 },
  { keys: ["tofu", "firm tofu", "fried tofu"], kcal: 145, carbs: 3, protein: 15, fat: 8.5, fiber: 1.5, sugars: 1, satFat: 1.3 },
  { keys: ["edamame"], kcal: 122, carbs: 10, protein: 11, fat: 5, fiber: 5, sugars: 2, satFat: 0.6 },
  { keys: ["tempeh"], kcal: 195, carbs: 9, protein: 20, fat: 11, fiber: 6, sugars: 0, satFat: 2 },

  // ---- Vegetables ----
  { keys: ["zucchini", "courgette"], kcal: 17, carbs: 3.1, protein: 1.2, fat: 0.3, fiber: 1, sugars: 2.5, satFat: 0.1 },
  { keys: ["carrot", "carrots"], kcal: 41, carbs: 9.6, protein: 0.9, fat: 0.2, fiber: 2.8, sugars: 4.7, satFat: 0 },
  { keys: ["mushroom", "mushrooms", "sauteed mushrooms"], kcal: 22, carbs: 3.3, protein: 3.1, fat: 0.3, fiber: 1, sugars: 2, satFat: 0.1 },
  { keys: ["cucumber"], kcal: 15, carbs: 3.6, protein: 0.7, fat: 0.1, fiber: 0.5, sugars: 1.7, satFat: 0 },
  { keys: ["sweet corn", "corn on the cob", "corn kernels", "corn"], kcal: 96, carbs: 21, protein: 3.4, fat: 1.5, fiber: 2.4, sugars: 4.5, satFat: 0.2 },
  { keys: ["asparagus"], kcal: 22, carbs: 4, protein: 2.4, fat: 0.2, fiber: 2, sugars: 2, satFat: 0 },
  { keys: ["green beans", "string beans"], kcal: 31, carbs: 7, protein: 1.8, fat: 0.2, fiber: 2.7, sugars: 3.3, satFat: 0 },
  { keys: ["brussels sprouts"], kcal: 43, carbs: 9, protein: 3.4, fat: 0.3, fiber: 3.8, sugars: 2.2, satFat: 0.1 },
  { keys: ["cabbage"], kcal: 25, carbs: 5.8, protein: 1.3, fat: 0.1, fiber: 2.5, sugars: 3.2, satFat: 0 },
  { keys: ["kale", "sauteed kale"], kcal: 49, carbs: 9, protein: 4.3, fat: 0.9, fiber: 2, sugars: 2.3, satFat: 0.1 },
  { keys: ["avocado"], kcal: 160, carbs: 8.5, protein: 2, fat: 14.7, fiber: 6.7, sugars: 0.7, satFat: 2.1 },
  { keys: ["sweet potato", "roasted sweet potato"], kcal: 90, carbs: 21, protein: 2, fat: 0.1, fiber: 3, sugars: 4.2, satFat: 0 },
  { keys: ["baked potato", "roasted potato", "roast potatoes"], kcal: 130, carbs: 24, protein: 2.5, fat: 3, fiber: 2.3, sugars: 1.2, satFat: 0.5 },
  { keys: ["beetroot", "beets"], kcal: 43, carbs: 10, protein: 1.6, fat: 0.2, fiber: 2.8, sugars: 7, satFat: 0 },
  { keys: ["radish"], kcal: 16, carbs: 3.4, protein: 0.7, fat: 0.1, fiber: 1.6, sugars: 1.9, satFat: 0 },
  { keys: ["celery"], kcal: 14, carbs: 3, protein: 0.7, fat: 0.2, fiber: 1.6, sugars: 1.3, satFat: 0 },
  { keys: ["artichoke"], kcal: 47, carbs: 10.5, protein: 3.3, fat: 0.2, fiber: 5.4, sugars: 1, satFat: 0 },
  { keys: ["leek", "leeks"], kcal: 61, carbs: 14, protein: 1.5, fat: 0.3, fiber: 1.8, sugars: 3.9, satFat: 0 },
  { keys: ["shallot", "shallots"], kcal: 72, carbs: 17, protein: 2.5, fat: 0.1, fiber: 3.2, sugars: 7.9, satFat: 0 },

  // ---- Fruits ----
  { keys: ["banana"], kcal: 89, carbs: 23, protein: 1.1, fat: 0.3, fiber: 2.6, sugars: 12, satFat: 0.1 },
  { keys: ["apple"], kcal: 52, carbs: 14, protein: 0.3, fat: 0.2, fiber: 2.4, sugars: 10, satFat: 0 },
  { keys: ["strawberries", "strawberry"], kcal: 32, carbs: 7.7, protein: 0.7, fat: 0.3, fiber: 2, sugars: 4.9, satFat: 0 },
  { keys: ["blueberries"], kcal: 57, carbs: 14.5, protein: 0.7, fat: 0.3, fiber: 2.4, sugars: 10, satFat: 0 },
  { keys: ["grapes"], kcal: 69, carbs: 18, protein: 0.7, fat: 0.2, fiber: 0.9, sugars: 16, satFat: 0.1 },
  { keys: ["orange"], kcal: 47, carbs: 12, protein: 0.9, fat: 0.1, fiber: 2.4, sugars: 9.4, satFat: 0 },
  { keys: ["mango"], kcal: 60, carbs: 15, protein: 0.8, fat: 0.4, fiber: 1.6, sugars: 14, satFat: 0.1 },
  { keys: ["pineapple"], kcal: 50, carbs: 13, protein: 0.5, fat: 0.1, fiber: 1.4, sugars: 10, satFat: 0 },
  { keys: ["watermelon"], kcal: 30, carbs: 7.6, protein: 0.6, fat: 0.2, fiber: 0.4, sugars: 6.2, satFat: 0 },
  { keys: ["pear"], kcal: 57, carbs: 15, protein: 0.4, fat: 0.1, fiber: 3.1, sugars: 10, satFat: 0 },
  { keys: ["peach"], kcal: 39, carbs: 9.5, protein: 0.9, fat: 0.3, fiber: 1.5, sugars: 8.4, satFat: 0 },
  { keys: ["kiwi"], kcal: 61, carbs: 15, protein: 1.1, fat: 0.5, fiber: 3, sugars: 9, satFat: 0 },
  { keys: ["pomegranate"], kcal: 83, carbs: 19, protein: 1.7, fat: 1.2, fiber: 4, sugars: 14, satFat: 0.1 },

  // ---- Grains / starches / breads ----
  { keys: ["quinoa", "cooked quinoa"], kcal: 120, carbs: 21, protein: 4.4, fat: 1.9, fiber: 2.8, sugars: 0.9, satFat: 0.2 },
  { keys: ["couscous", "cooked couscous"], kcal: 112, carbs: 23, protein: 3.8, fat: 0.2, fiber: 1.4, sugars: 0.1, satFat: 0 },
  { keys: ["barley", "cooked barley"], kcal: 123, carbs: 28, protein: 2.3, fat: 0.4, fiber: 3.8, sugars: 0.3, satFat: 0.1 },
  { keys: ["polenta"], kcal: 85, carbs: 18, protein: 2, fat: 0.5, fiber: 1, sugars: 0.5, satFat: 0.1 },
  { keys: ["tortilla", "flour tortilla"], kcal: 300, carbs: 48, protein: 8, fat: 8, fiber: 3, sugars: 2, satFat: 2 },
  { keys: ["corn tortilla"], kcal: 218, carbs: 45, protein: 5.7, fat: 2.9, fiber: 6.3, sugars: 0.9, satFat: 0.4 },
  { keys: ["bagel"], kcal: 250, carbs: 49, protein: 10, fat: 1.5, fiber: 2, sugars: 5, satFat: 0.2 },
  { keys: ["english muffin"], kcal: 227, carbs: 45, protein: 8.2, fat: 1.6, fiber: 2.5, sugars: 3, satFat: 0.3 },
  { keys: ["multigrain bread", "whole wheat bread", "wheat bread"], kcal: 250, carbs: 43, protein: 11, fat: 3.5, fiber: 6.5, sugars: 5, satFat: 0.7 },
  { keys: ["sourdough bread", "sourdough"], kcal: 270, carbs: 52, protein: 9.5, fat: 1.5, fiber: 2.5, sugars: 2.5, satFat: 0.3 },
  { keys: ["dinner roll", "bread roll"], kcal: 280, carbs: 50, protein: 8.5, fat: 5, fiber: 2, sugars: 5, satFat: 1.2 },
  { keys: ["hash browns"], kcal: 265, carbs: 27, protein: 3.5, fat: 16.5, fiber: 2.5, sugars: 0.5, satFat: 2.5 },
  { keys: ["home fries", "breakfast potatoes"], kcal: 150, carbs: 20, protein: 2.5, fat: 7, fiber: 2, sugars: 1, satFat: 1 },

  // ---- Legumes / plant proteins ----
  { keys: ["lentils", "cooked lentils"], kcal: 116, carbs: 20, protein: 9, fat: 0.4, fiber: 7.9, sugars: 1.8, satFat: 0.1 },
  { keys: ["chickpeas cooked", "cooked chickpeas"], kcal: 164, carbs: 27, protein: 8.9, fat: 2.6, fiber: 7.6, sugars: 4.8, satFat: 0.3 },
  { keys: ["black beans cooked"], kcal: 132, carbs: 24, protein: 8.9, fat: 0.5, fiber: 8.7, sugars: 0.3, satFat: 0.1 },
  { keys: ["pinto beans"], kcal: 143, carbs: 26, protein: 9, fat: 0.6, fiber: 9, sugars: 0.3, satFat: 0.1 },
  { keys: ["refried beans"], kcal: 100, carbs: 15, protein: 6, fat: 1.5, fiber: 5.5, sugars: 0.5, satFat: 0.4 },
  { keys: ["green peas"], kcal: 81, carbs: 14, protein: 5.4, fat: 0.4, fiber: 5.5, sugars: 5.7, satFat: 0.1 },

  // ---- Nuts / seeds ----
  { keys: ["almonds"], kcal: 579, carbs: 22, protein: 21, fat: 50, fiber: 12.5, sugars: 4.4, satFat: 3.8 },
  { keys: ["walnuts"], kcal: 654, carbs: 14, protein: 15, fat: 65, fiber: 6.7, sugars: 2.6, satFat: 6.1 },
  { keys: ["cashews"], kcal: 553, carbs: 30, protein: 18, fat: 44, fiber: 3.3, sugars: 5.9, satFat: 7.8 },
  { keys: ["peanuts", "roasted peanuts"], kcal: 567, carbs: 16, protein: 26, fat: 49, fiber: 8.5, sugars: 4, satFat: 6.8 },
  { keys: ["peanut butter"], kcal: 588, carbs: 20, protein: 25, fat: 50, fiber: 6, sugars: 9, satFat: 10 },
  { keys: ["chia seeds"], kcal: 486, carbs: 42, protein: 17, fat: 31, fiber: 34, sugars: 0, satFat: 3.3 },
  { keys: ["sunflower seeds"], kcal: 584, carbs: 20, protein: 21, fat: 51, fiber: 8.6, sugars: 2.6, satFat: 4.5 },
  { keys: ["pistachios"], kcal: 560, carbs: 28, protein: 20, fat: 45, fiber: 10.6, sugars: 7.7, satFat: 5.4 },

  // ---- Condiments / sauces / dressings ----
  { keys: ["ketchup", "tomato ketchup"], kcal: 112, carbs: 27, protein: 1.2, fat: 0.2, fiber: 0.4, sugars: 22, satFat: 0 },
  { keys: ["mustard", "yellow mustard"], kcal: 66, carbs: 5.8, protein: 4.4, fat: 3.3, fiber: 3.3, sugars: 2.6, satFat: 0.2 },
  { keys: ["soy sauce"], kcal: 53, carbs: 4.9, protein: 8, fat: 0.6, fiber: 0.8, sugars: 0.4, satFat: 0.1 },
  { keys: ["bbq sauce", "barbecue sauce"], kcal: 172, carbs: 40, protein: 1, fat: 0.6, fiber: 0.5, sugars: 33, satFat: 0.1 },
  { keys: ["hot sauce", "sriracha"], kcal: 93, carbs: 20, protein: 2, fat: 0.9, fiber: 1.2, sugars: 14, satFat: 0.1 },
  { keys: ["pesto"], kcal: 460, carbs: 5, protein: 6, fat: 47, fiber: 1.5, sugars: 1.5, satFat: 8.5 },
  { keys: ["alfredo sauce"], kcal: 190, carbs: 4, protein: 4.5, fat: 18, fiber: 0.2, sugars: 1.5, satFat: 10 },
  { keys: ["honey"], kcal: 304, carbs: 82, protein: 0.3, fat: 0, fiber: 0.2, sugars: 82, satFat: 0 },
  { keys: ["maple syrup"], kcal: 260, carbs: 67, protein: 0, fat: 0, fiber: 0, sugars: 60, satFat: 0 },
  { keys: ["balsamic vinegar"], kcal: 88, carbs: 17, protein: 0.5, fat: 0, fiber: 0, sugars: 15, satFat: 0 },
  { keys: ["vinaigrette", "italian dressing"], kcal: 310, carbs: 8, protein: 0.5, fat: 31, fiber: 0, sugars: 6, satFat: 4.5 },
  { keys: ["sesame oil"], kcal: 884, carbs: 0, protein: 0, fat: 100, fiber: 0, sugars: 0, satFat: 14.2 },
  { keys: ["coconut milk"], kcal: 230, carbs: 5.5, protein: 2.3, fat: 24, fiber: 2.2, sugars: 3.3, satFat: 21 },
  { keys: ["salsa"], kcal: 36, carbs: 8, protein: 1.5, fat: 0.2, fiber: 2, sugars: 4, satFat: 0 },
  { keys: ["sour cream and onion dip", "cream sauce"], kcal: 195, carbs: 5, protein: 3, fat: 18, fiber: 0.2, sugars: 3, satFat: 11 },

  // ---- Common prepared breakfast/snack items not covered elsewhere ----
  { keys: ["greek yogurt bowl", "yogurt parfait"], kcal: 130, carbs: 18, protein: 8, fat: 3, fiber: 1.5, sugars: 14, satFat: 1.5 },
  { keys: ["smoothie bowl", "acai bowl"], kcal: 145, carbs: 27, protein: 3, fat: 3.5, fiber: 4, sugars: 18, satFat: 1 },
  { keys: ["protein bar"], kcal: 380, carbs: 40, protein: 25, fat: 13, fiber: 8, sugars: 20, satFat: 6 },
  { keys: ["muffin", "blueberry muffin"], kcal: 375, carbs: 55, protein: 6, fat: 15, fiber: 2, sugars: 28, satFat: 3 },
  { keys: ["donut", "doughnut"], kcal: 420, carbs: 51, protein: 5, fat: 22, fiber: 1.5, sugars: 25, satFat: 8.5 },
  { keys: ["biscuit", "buttermilk biscuit"], kcal: 350, carbs: 45, protein: 6.5, fat: 16, fiber: 1.5, sugars: 4, satFat: 4 },
  { keys: ["gravy"], kcal: 65, carbs: 5, protein: 2, fat: 4, fiber: 0.3, sugars: 0.5, satFat: 1.5 },
];

function normalize(str) {
  return (str || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}

/**
 * Same matching strategy as lookupIndianFood/lookupWorldFood: keyword-based
 * substring match, preferring the longest (most specific) key. Kept as a
 * separate module so it can be prioritized independently in analyse.js —
 * checked after the two cuisine-dish DBs so a specific named dish always
 * wins over a generic ingredient match.
 */
function lookupIngredient(name) {
  const q = normalize(name);
  if (!q) return null;

  let best = null;
  let bestLen = 0;

  for (const entry of INGREDIENTS_DB) {
    for (const key of entry.keys) {
      if (q.includes(key) && key.length > bestLen) {
        best = entry;
        bestLen = key.length;
      }
    }
  }

  if (!best) return null;
  const { kcal, carbs, protein, fat, fiber, sugars, satFat } = best;
  return { kcal, carbs, protein, fat, fiber, sugars, satFat };
}

module.exports = { lookupIngredient, INGREDIENTS_DB };
