// ─────────────────────────────────────────────────────────────────────────
// USDA FoodData Central lookup
//
// Free, public-domain, government-verified nutrition data (Foundation
// Foods + SR Legacy) for ~400,000 raw ingredients and generic prepared
// foods. Added as a lookup tier BETWEEN the curated cuisine databases
// and the raw per-ingredient VLM guess (Tier 3) in analyse.js, because:
//
//   - It is much deeper than the ~140-entry curated DBs for common,
//     single-ingredient ("chicken breast", "broccoli", "cheddar cheese")
//     and generic-preparation ("scrambled egg", "grilled salmon") lookups
//     that aren't specific enough to need a cuisine-specific dish entry.
//   - It is NOT a substitute for the curated DBs on composite home-cooked
//     dishes (a curry, a biryani, a bolognese) — FDC has essentially no
//     restaurant or regional-recipe coverage, which is exactly why those
//     curated files exist and are still checked first.
//   - It is NOT a substitute for Open Food Facts on packaged/branded
//     products either — FDC's Branded Foods dataset is US-centric and
//     less complete internationally than OFF for that use case.
//
// So the final resolution order for Case B (homemade) ingredients is:
//   Indian DB -> World DB -> USDA FDC -> Open Food Facts -> VLM estimate
//
// Docs: https://fdc.nal.usda.gov/api-guide.html
// Get a free key (recommended over DEMO_KEY, which is capped at 30
// req/hour) at https://api.data.gov/signup — set as USDA_FDC_API_KEY.
// ─────────────────────────────────────────────────────────────────────────

const FDC_BASE = "https://api.nal.usda.gov/fdc/v1";

// Nutrient numbers are stable identifiers across all FDC data types
// (unlike nutrient "id", which can vary), so we match on these rather
// than on nutrient name strings.
const NUTRIENT_NUMBERS = {
  kcal: "208",
  protein: "203",
  fat: "204",
  carbs: "205",
  fiber: "291",
  sugars: "269",
  satFat: "606",
  sodium: "307", // mg per 100g
  calcium: "301", // mg
  iron: "303",    // mg
  potassium: "306", // mg
  magnesium: "304", // mg
  zinc: "309",       // mg
  vitaminC: "401",   // mg
  vitaminA: "320"    // µg RAE
};

function normalize(str) {
  return (str || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}

// Same word-overlap scoring approach used for Open Food Facts name
// matching (nameMatchScore in analyse.js) — kept as a local copy here so
// this module has no dependency on analyse.js and can be tested/swapped
// independently.
function nameMatchScore(query, description) {
  const qWords = new Set(normalize(query).split(" ").filter(w => w.length > 1));
  if (!qWords.size) return 0;
  const cWords = new Set(normalize(description).split(" ").filter(w => w.length > 1));
  let overlap = 0;
  for (const w of qWords) if (cWords.has(w)) overlap++;
  return overlap / qWords.size;
}

function extractNutrient(foodNutrients, key) {
  const num = NUTRIENT_NUMBERS[key];
  const hit = (foodNutrients || []).find(n => String(n.nutrientNumber) === num);
  return hit && typeof hit.value === "number" ? hit.value
       : hit && typeof hit.amount === "number" ? hit.amount
       : 0;
}

/**
 * Search USDA FoodData Central for a generic ingredient/food name and
 * return per-100g macros, or null if no confident match is found.
 * Restricted to Foundation + SR Legacy data types (lab-analyzed generic
 * foods, always reported per 100g) — deliberately excluding Branded and
 * Survey(FNDDS) here, since Branded is better covered by Open Food Facts
 * already, and Survey entries are "as eaten" composite dishes that are
 * out of scope for this tier (that's what the curated DBs are for).
 */
async function lookupUsdaFood(name, timeoutMs = 6000) {
  const apiKey = process.env.USDA_FDC_API_KEY || "DEMO_KEY";
  if (!name) return null;

  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const url = `${FDC_BASE}/foods/search?api_key=${encodeURIComponent(apiKey)}` +
      `&query=${encodeURIComponent(name)}` +
      `&pageSize=8` +
      `&dataType=${encodeURIComponent("Foundation,SR Legacy")}`;

    const r = await fetch(url, { signal: controller.signal });
    if (!r.ok) return null; // includes 429 (DEMO_KEY rate limit) — fall through quietly

    const data = await r.json();
    const foods = data.foods || [];
    if (!foods.length) return null;

    const scored = foods.map(f => ({ f, score: nameMatchScore(name, f.description || "") }));
    scored.sort((a, b) => b.score - a.score);

    const best = scored[0];
    // Same 0.34 overlap threshold used for the OFF name match, for
    // consistency in how "confident enough to use" is defined across
    // every lookup tier.
    if (!best || best.score < 0.34) return null;

    const fn = best.f.foodNutrients || [];
    const kcal = extractNutrient(fn, "kcal");
    if (!kcal) return null; // no usable energy value — treat as no match

    return {
      kcal,
      carbs: extractNutrient(fn, "carbs"),
      protein: extractNutrient(fn, "protein"),
      fat: extractNutrient(fn, "fat"),
      fiber: extractNutrient(fn, "fiber"),
      sugars: extractNutrient(fn, "sugars"),
      satFat: extractNutrient(fn, "satFat"),
      micros: {
        calcium: extractNutrient(fn, "calcium"),
        iron: extractNutrient(fn, "iron"),
        potassium: extractNutrient(fn, "potassium"),
        magnesium: extractNutrient(fn, "magnesium"),
        zinc: extractNutrient(fn, "zinc"),
        vitaminC: extractNutrient(fn, "vitaminC"),
        vitaminA: extractNutrient(fn, "vitaminA")
      },
      description: best.f.description,
      fdcId: best.f.fdcId
    };
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

module.exports = { lookupUsdaFood };
