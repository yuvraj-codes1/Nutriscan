# Security notes

## API key handling

- `NVIDIA_API_KEY` is read only in `api/analyse.js` (a Node serverless
  function) via `process.env.NVIDIA_API_KEY`. It is never embedded in
  `index.html`, never sent to the browser in any response, and never
  logged (errors are logged as `err`/`err.message`, which don't include
  the key).
- There is no hard-coded key anywhere in this codebase — confirmed by
  searching for API key patterns; the only two calls that need
  credentials (NVIDIA chat-completions, and Open Food Facts which is a
  public, keyless API) already use `process.env` / no key.

## Rotating the NVIDIA API key

1. Generate a new key at https://build.nvidia.com (API Keys section).
2. In Vercel: Project → Settings → Environment Variables → update
   `NVIDIA_API_KEY` for the relevant environment(s) (Production/Preview/
   Development), then redeploy (env var changes require a redeploy to
   take effect for already-built functions).
3. Revoke the old key from the NVIDIA dashboard once the new deploy is
   confirmed healthy.
4. Locally, update your `.env` (copied from `.env.example`) — never commit it.

Rotate immediately if a key is ever exposed (e.g. committed to git
history, pasted in a support ticket, or visible in a log). If it may have
been committed, also purge it from git history (`git filter-repo` or
BFG Repo-Cleaner), not just the latest commit.

## Rate limiting

`api/_lib/rate-limit.js` applies per-IP (and, once authentication exists,
per-user) limits with standard `X-RateLimit-*` headers and a `429` +
`Retry-After` when exceeded. It's in-memory and per-instance, which is a
reasonable free baseline on Vercel but is **not** strictly consistent
across concurrent instances — for guaranteed global limits under high
traffic, swap in a shared store (Upstash Redis / Vercel KV); the limiting
logic itself doesn't need to change.

## Input validation

`api/_lib/validate.js` enforces a strict whitelist schema on the request
body: only the `image` field is accepted, unexpected fields are rejected,
and the image is checked for type, length bounds, valid base64, and
correct magic bytes (JPEG/PNG/WebP) before being sent to the model.

## CORS

The API no longer sends `Access-Control-Allow-Origin: *`. Set
`ALLOWED_ORIGIN` to your deployed frontend origin(s) if you need
cross-origin access; otherwise the API is same-origin-only by default.

## Data-integrity fix: numeric coercion of vision-model output

The vision model's JSON replies are not schema-guaranteed. A gram value
occasionally came back as a numeric *string* (e.g. `"90"` or `"120g"`)
instead of a number. Left unguarded, `totalGrams = resolved.reduce((s, r)
=> s + r.grams, 0)` would silently switch from addition to string
concatenation the moment it hit a string operand (`150 + "90"` → `"15090"`,
not `240`), corrupting the dish's total weight into a huge string-turned-
number. That value became `estimated_grams`, which the frontend's portion
adjuster uses as the scaling denominator — so touching the portion control
collapsed every ingredient row to ~0g / 0 kcal, which looked exactly like
an empty ingredients list.

Fix: added a shared `safeNum()` coercion helper (`api/analyse.js`) applied
at every point a number originates from the vision model or an external
API (component `grams`/`name`, Tier 3/4 nutrient values, `total_grams`,
the totals reduction, and the final response mapping), plus a matching
client-side `safeNum()` in `index.html` as a second line of defense.
Verified with an end-to-end test that feeds the real malformed shape
through the actual production handler.

## Cross-provider fallback: NVIDIA free-tier hang issue

NVIDIA's free `/v1/chat/completions` endpoint has a documented, currently
unresolved pattern on NVIDIA's own developer forums where requests connect
instantly but then hang indefinitely on some accounts/regions — unrelated
to API key validity or request correctness. `/v1/models` and other
endpoints are unaffected; only actual inference calls hang. This surfaced
in production as every model call aborting at its timeout with no error
detail, even on a freshly created project with a valid, freshly-generated
key.

A second NVIDIA-hosted model doesn't help when this is the failure mode,
since it's often account/region-wide across NVIDIA's whole
`/chat/completions` surface rather than model-specific.

Fix: added Google Gemini (`gemini-2.5-flash`) as an optional Tier 3
fallback, called via plain REST (no SDK dependency) on genuinely separate
infrastructure. It only activates if both NVIDIA tiers fail AND
`GEMINI_API_KEY` is set in the environment — if unset, the app behaves
exactly as it did with NVIDIA alone, so this is a pure, backward-compatible
addition. Get a free key at https://aistudio.google.com/apikey.

Verified with two end-to-end tests: (1) both NVIDIA tiers made to fail,
confirming Gemini is correctly invoked with the right request shape and
successfully returns a usable result; (2) `GEMINI_API_KEY` unset, confirming
Gemini is never called and NVIDIA-only behavior is unchanged.

## Accuracy improvements: vitamins/minerals + prompt grounding

**Vitamins & minerals were showing empty** for dishes where ingredients
matched a curated cuisine database (Indian/world) first — those databases
only track macros (calories/carbs/protein/fat/fiber), never micronutrients,
so `vitamins_minerals` ended up empty whenever most components resolved
against them rather than USDA. Fixed by adding a best-effort supplementary
USDA lookup (`lookupSupplementaryMicros`) that enriches curated-DB matches
with micronutrient data without overriding their (more accurate,
dish-aware) macro numbers. Failure to find a USDA match or a network error
here silently yields no micros for that ingredient rather than affecting
the main result.

**Prompt grounding improved** for two paths:
- `TRIAGE_PROMPT` (main dish decomposition): added explicit guidance on
  high-fat components (cheese, sausage, oil, butter) with concrete visual
  reference points, since these were the recurring source of inflated fat/
  calorie totals (the model's own confidence_reasons had already started
  flagging "fat accounts for 58%+ of calories" as suspicious — this gives
  it the grounding to catch that before finalizing, not just after).
- `ingredientEstimatePrompt` (Tier 4 fallback, used when nothing else
  matched): was a single unstructured line; now asks for
  standard/typical values explicitly and includes a macro/calorie
  consistency self-check, matching the rigor already present in the
  triage and label-reading prompts.
