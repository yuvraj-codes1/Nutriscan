// ─────────────────────────────────────────────────────────────────────────
// Indian Food Nutrition Database
//
// A curated, per-100g nutrition table for common Indian ingredients and
// prepared dish components, values as-cooked/as-served (i.e. including
// typical oil/ghee, not raw/dry weights) so they line up with visual
// gram estimates from a plate photo. Compiled from typical figures
// reported in Indian Food Composition Tables (IFCT 2017, NIN Hyderabad)
// and standard Indian nutrition references, rounded to sensible
// precision for an estimator (not a lab-grade source).
//
// This is checked BEFORE Open Food Facts for Case B (homemade/restaurant)
// ingredient resolution, since OFF is overwhelmingly packaged Western/
// European branded products and has very poor coverage of generic Indian
// home-cooked items like dals, sabzis, and breads.
//
// Lookup is done via keyword matching against normalized ingredient
// names, so the VLM's free-text component names (e.g. "basmati rice",
// "chana masala gravy") should generally hit an entry here.
// ─────────────────────────────────────────────────────────────────────────

// Each entry: kcal, carbs, protein, fat, fiber, sugars, satFat — all per 100g.
const INDIAN_FOOD_DB = [
  // ---- Rice & grains ----
  { keys: ["basmati rice", "steamed rice", "plain rice", "white rice", "boiled rice"], kcal: 130, carbs: 28.2, protein: 2.7, fat: 0.3, fiber: 0.4, sugars: 0.1, satFat: 0.1 },
  { keys: ["jeera rice", "cumin rice"], kcal: 165, carbs: 29, protein: 3, fat: 4, fiber: 0.5, sugars: 0.2, satFat: 0.5 },
  { keys: ["brown rice"], kcal: 123, carbs: 25.6, protein: 2.7, fat: 1, fiber: 1.8, sugars: 0.2, satFat: 0.2 },
  { keys: ["pulao", "pilaf", "veg pulao", "vegetable pulao"], kcal: 172, carbs: 27, protein: 3.5, fat: 5.5, fiber: 1.2, sugars: 1, satFat: 0.8 },
  { keys: ["biryani rice", "biryani", "chicken biryani", "veg biryani", "mutton biryani"], kcal: 200, carbs: 25, protein: 8, fat: 7.5, fiber: 1, sugars: 1, satFat: 1.5 },
  { keys: ["poha", "flattened rice"], kcal: 130, carbs: 24, protein: 2.5, fat: 3, fiber: 1.2, sugars: 1, satFat: 0.4 },
  { keys: ["idli"], kcal: 130, carbs: 26, protein: 3.5, fat: 0.5, fiber: 0.8, sugars: 0.2, satFat: 0.1 },
  { keys: ["dosa", "masala dosa", "plain dosa"], kcal: 168, carbs: 27, protein: 3.7, fat: 5, fiber: 0.9, sugars: 0.4, satFat: 0.8 },
  { keys: ["upma"], kcal: 140, carbs: 20, protein: 3.5, fat: 5, fiber: 1.5, sugars: 0.5, satFat: 0.7 },
  { keys: ["khichdi"], kcal: 120, carbs: 20, protein: 4.5, fat: 2.5, fiber: 1.5, sugars: 0.3, satFat: 0.4 },

  // ---- Breads ----
  { keys: ["roti", "chapati", "phulka"], kcal: 297, carbs: 58, protein: 9.5, fat: 4, fiber: 4.5, sugars: 1, satFat: 0.8 },
  { keys: ["naan"], kcal: 310, carbs: 50, protein: 8.5, fat: 8, fiber: 2, sugars: 2, satFat: 2 },
  { keys: ["paratha", "aloo paratha", "plain paratha"], kcal: 330, carbs: 45, protein: 6.5, fat: 14, fiber: 3, sugars: 1, satFat: 5 },
  { keys: ["puri", "poori"], kcal: 380, carbs: 42, protein: 6, fat: 21, fiber: 2, sugars: 0.5, satFat: 7 },
  { keys: ["bhatura"], kcal: 350, carbs: 45, protein: 7, fat: 15, fiber: 1.5, sugars: 1, satFat: 5 },

  // ---- Dals / legumes (cooked, with typical tempering) ----
  { keys: ["chana masala", "chole", "chickpea curry", "channa"], kcal: 164, carbs: 18, protein: 7.5, fat: 6.5, fiber: 6, sugars: 3, satFat: 1 },
  { keys: ["chickpeas", "chana", "garbanzo", "kabuli chana"], kcal: 164, carbs: 27, protein: 8.9, fat: 2.6, fiber: 7.6, sugars: 4.8, satFat: 0.3 },
  { keys: ["dal", "daal", "toor dal", "arhar dal", "yellow dal"], kcal: 116, carbs: 16, protein: 7, fat: 3, fiber: 4, sugars: 1, satFat: 0.5 },
  { keys: ["dal makhani"], kcal: 195, carbs: 15, protein: 8, fat: 12, fiber: 5, sugars: 2, satFat: 5 },
  { keys: ["moong dal", "mung dal"], kcal: 105, carbs: 15, protein: 7.5, fat: 2, fiber: 4, sugars: 1, satFat: 0.3 },
  { keys: ["masoor dal", "red lentil"], kcal: 108, carbs: 16, protein: 7.8, fat: 2, fiber: 4, sugars: 1, satFat: 0.3 },
  { keys: ["rajma", "kidney bean curry"], kcal: 140, carbs: 18, protein: 8, fat: 4.5, fiber: 6.5, sugars: 2, satFat: 1 },
  { keys: ["sambar", "sambhar"], kcal: 90, carbs: 12, protein: 4.5, fat: 3, fiber: 3, sugars: 1.5, satFat: 0.4 },

  // ---- Vegetable curries / sabzis ----
  { keys: ["aloo gobi"], kcal: 120, carbs: 12, protein: 2.5, fat: 7, fiber: 3, sugars: 2, satFat: 1 },
  { keys: ["baingan bharta"], kcal: 110, carbs: 9, protein: 2, fat: 7.5, fiber: 3.5, sugars: 3, satFat: 1 },
  { keys: ["bhindi masala", "okra"], kcal: 100, carbs: 9, protein: 2.5, fat: 6.5, fiber: 3.5, sugars: 2, satFat: 0.9 },
  { keys: ["palak paneer", "spinach paneer"], kcal: 180, carbs: 7, protein: 9, fat: 13.5, fiber: 2.5, sugars: 2.5, satFat: 6.5 },
  { keys: ["saag", "sarson ka saag"], kcal: 95, carbs: 6, protein: 4, fat: 6, fiber: 3, sugars: 1.5, satFat: 2 },
  { keys: ["mixed vegetable curry", "veg curry", "sabzi"], kcal: 100, carbs: 10, protein: 2.5, fat: 6, fiber: 3, sugars: 2.5, satFat: 1 },
  { keys: ["kadai vegetable", "kadai paneer"], kcal: 190, carbs: 9, protein: 8, fat: 14, fiber: 2.5, sugars: 3, satFat: 6 },

  // ---- Paneer / dairy-based gravies ----
  { keys: ["paneer butter masala", "paneer makhani"], kcal: 260, carbs: 8, protein: 10, fat: 21, fiber: 1, sugars: 4, satFat: 11 },
  { keys: ["shahi paneer"], kcal: 250, carbs: 9, protein: 9.5, fat: 20, fiber: 1, sugars: 4, satFat: 10 },
  { keys: ["paneer", "cottage cheese"], kcal: 265, carbs: 3.4, protein: 18.3, fat: 20.8, fiber: 0, sugars: 2.6, satFat: 13 },
  { keys: ["butter chicken", "murgh makhani"], kcal: 220, carbs: 6, protein: 16, fat: 15, fiber: 0.5, sugars: 3, satFat: 6 },
  { keys: ["chicken tikka masala"], kcal: 195, carbs: 6, protein: 17, fat: 12, fiber: 1, sugars: 3, satFat: 4.5 },
  { keys: ["korma", "chicken korma", "veg korma"], kcal: 210, carbs: 7, protein: 13, fat: 15, fiber: 1, sugars: 3, satFat: 6 },

  // ---- Meat / chicken / fish curries ----
  { keys: ["chicken curry"], kcal: 165, carbs: 5, protein: 17, fat: 9, fiber: 1, sugars: 2, satFat: 2.5 },
  { keys: ["mutton curry", "lamb curry", "goat curry"], kcal: 220, carbs: 4, protein: 19, fat: 14, fiber: 0.5, sugars: 1.5, satFat: 5 },
  { keys: ["fish curry"], kcal: 150, carbs: 4, protein: 18, fat: 7, fiber: 0.5, sugars: 1.5, satFat: 1.5 },
  { keys: ["tandoori chicken"], kcal: 170, carbs: 2, protein: 25, fat: 7, fiber: 0.3, sugars: 1, satFat: 2 },
  { keys: ["chicken tikka"], kcal: 175, carbs: 3, protein: 24, fat: 7.5, fiber: 0.5, sugars: 1.5, satFat: 2 },
  { keys: ["egg curry"], kcal: 160, carbs: 4, protein: 10, fat: 11, fiber: 0.5, sugars: 1.5, satFat: 3 },

  // ---- Snacks / street food ----
  { keys: ["samosa"], kcal: 260, carbs: 28, protein: 4.5, fat: 15, fiber: 2.5, sugars: 1.5, satFat: 3 },
  { keys: ["pakora", "bhajiya", "bhaji"], kcal: 280, carbs: 22, protein: 5, fat: 19, fiber: 2.5, sugars: 1, satFat: 3.5 },
  { keys: ["vada", "medu vada"], kcal: 245, carbs: 22, protein: 6.5, fat: 15, fiber: 3, sugars: 0.5, satFat: 2.5 },
  { keys: ["dhokla"], kcal: 160, carbs: 22, protein: 6, fat: 5, fiber: 1.5, sugars: 3, satFat: 0.8 },
  { keys: ["pani puri", "gol gappa"], kcal: 320, carbs: 55, protein: 6, fat: 9, fiber: 2, sugars: 3, satFat: 1.5 },
  { keys: ["bhel puri"], kcal: 220, carbs: 35, protein: 5, fat: 7, fiber: 3, sugars: 6, satFat: 1 },
  { keys: ["pav bhaji"], kcal: 210, carbs: 27, protein: 4.5, fat: 9.5, fiber: 3.5, sugars: 4, satFat: 3.5 },
  { keys: ["chaat"], kcal: 200, carbs: 30, protein: 4.5, fat: 7.5, fiber: 3, sugars: 6, satFat: 1.2 },

  // ---- Yogurt / raita / accompaniments ----
  { keys: ["raita"], kcal: 65, carbs: 5, protein: 3, fat: 3.5, fiber: 0.5, sugars: 4, satFat: 2 },
  { keys: ["curd", "yogurt", "dahi"], kcal: 60, carbs: 4.7, protein: 3.5, fat: 3.3, fiber: 0, sugars: 4.7, satFat: 2.1 },
  { keys: ["papad", "papadum"], kcal: 370, carbs: 60, protein: 22, fat: 3, fiber: 6, sugars: 1, satFat: 0.5 },
  { keys: ["pickle", "achaar"], kcal: 180, carbs: 15, protein: 1.5, fat: 13, fiber: 3, sugars: 4, satFat: 1.5 },
  { keys: ["mint chutney", "coriander chutney", "green chutney"], kcal: 60, carbs: 8, protein: 2, fat: 2.5, fiber: 2, sugars: 2, satFat: 0.3 },
  { keys: ["tamarind chutney", "sweet chutney"], kcal: 150, carbs: 37, protein: 1, fat: 0.3, fiber: 1.5, sugars: 28, satFat: 0.1 },

  // ---- Sweets / desserts ----
  { keys: ["gulab jamun"], kcal: 330, carbs: 45, protein: 4, fat: 15, fiber: 0.5, sugars: 38, satFat: 7 },
  { keys: ["jalebi"], kcal: 350, carbs: 55, protein: 2.5, fat: 13, fiber: 0.3, sugars: 40, satFat: 6 },
  { keys: ["rasgulla"], kcal: 186, carbs: 32, protein: 4.5, fat: 4.5, fiber: 0, sugars: 28, satFat: 2.5 },
  { keys: ["kheer", "rice pudding"], kcal: 130, carbs: 20, protein: 3.5, fat: 4, fiber: 0.3, sugars: 16, satFat: 2.5 },
  { keys: ["halwa", "gajar halwa", "carrot halwa"], kcal: 250, carbs: 30, protein: 3, fat: 13, fiber: 1.5, sugars: 24, satFat: 6 },
  { keys: ["ladoo", "laddu"], kcal: 400, carbs: 50, protein: 6, fat: 19, fiber: 1.5, sugars: 30, satFat: 8 },
  { keys: ["barfi"], kcal: 420, carbs: 55, protein: 6, fat: 20, fiber: 0.5, sugars: 45, satFat: 11 },

  // ---- South Indian (beyond the basics already listed above) ----
  { keys: ["rava dosa", "onion rava dosa"], kcal: 190, carbs: 24, protein: 4, fat: 8, fiber: 0.8, sugars: 1, satFat: 1.2 },
  { keys: ["uttapam", "uthappam"], kcal: 165, carbs: 25, protein: 4.5, fat: 5, fiber: 1.2, sugars: 1.5, satFat: 0.8 },
  { keys: ["appam"], kcal: 155, carbs: 28, protein: 2.5, fat: 3.5, fiber: 0.6, sugars: 2, satFat: 1.8 },
  { keys: ["idiyappam", "string hoppers"], kcal: 135, carbs: 29, protein: 2.3, fat: 0.5, fiber: 0.5, sugars: 0.2, satFat: 0.1 },
  { keys: ["puttu"], kcal: 145, carbs: 30, protein: 3, fat: 1.5, fiber: 1.2, sugars: 0.3, satFat: 0.9 },
  { keys: ["rasam"], kcal: 45, carbs: 6, protein: 1.8, fat: 1.5, fiber: 1, sugars: 1.5, satFat: 0.2 },
  { keys: ["curd rice", "yogurt rice", "thayir sadam"], kcal: 145, carbs: 22, protein: 4, fat: 4, fiber: 0.5, sugars: 3, satFat: 2 },
  { keys: ["lemon rice", "chitranna"], kcal: 175, carbs: 28, protein: 3, fat: 6, fiber: 0.8, sugars: 1, satFat: 0.7 },
  { keys: ["tamarind rice", "puliyodarai", "pulihora"], kcal: 190, carbs: 30, protein: 3, fat: 7, fiber: 1, sugars: 2, satFat: 0.8 },
  { keys: ["coconut chutney"], kcal: 180, carbs: 6, protein: 3, fat: 16, fiber: 3, sugars: 1.5, satFat: 12 },
  { keys: ["avial"], kcal: 105, carbs: 8, protein: 2.5, fat: 7, fiber: 3, sugars: 3, satFat: 3.5 },
  { keys: ["kootu"], kcal: 95, carbs: 12, protein: 4.5, fat: 3, fiber: 3.5, sugars: 2, satFat: 0.6 },
  { keys: ["chettinad chicken", "chicken chettinad"], kcal: 200, carbs: 5, protein: 17, fat: 13, fiber: 1, sugars: 2, satFat: 4 },
  { keys: ["fish moilee", "meen moilee"], kcal: 150, carbs: 4, protein: 15, fat: 8.5, fiber: 0.5, sugars: 2, satFat: 5 },
  { keys: ["hyderabadi biryani"], kcal: 210, carbs: 24, protein: 9, fat: 8.5, fiber: 1, sugars: 1, satFat: 2 },
  { keys: ["mysore pak"], kcal: 480, carbs: 48, protein: 4, fat: 30, fiber: 0.5, sugars: 35, satFat: 15 },

  // ---- Bengali ----
  { keys: ["shorshe ilish", "hilsa curry"], kcal: 175, carbs: 3, protein: 16, fat: 11, fiber: 0.5, sugars: 1, satFat: 2 },
  { keys: ["macher jhol", "fish curry bengali"], kcal: 130, carbs: 4, protein: 15, fat: 6, fiber: 0.5, sugars: 1.5, satFat: 1 },
  { keys: ["aloo posto"], kcal: 150, carbs: 15, protein: 3, fat: 9, fiber: 2, sugars: 1.5, satFat: 1 },
  { keys: ["cholar dal", "chana dal bengali"], kcal: 140, carbs: 18, protein: 7, fat: 5, fiber: 4.5, sugars: 3, satFat: 1.5 },
  { keys: ["luchi"], kcal: 340, carbs: 40, protein: 6, fat: 18, fiber: 1.5, sugars: 0.5, satFat: 6 },
  { keys: ["rasgulla bengali"], kcal: 186, carbs: 32, protein: 4.5, fat: 4.5, fiber: 0, sugars: 28, satFat: 2.5 },
  { keys: ["sandesh"], kcal: 300, carbs: 40, protein: 10, fat: 11, fiber: 0, sugars: 32, satFat: 6.5 },
  { keys: ["mishti doi", "sweet yogurt"], kcal: 150, carbs: 22, protein: 5, fat: 4.5, fiber: 0, sugars: 20, satFat: 2.8 },

  // ---- Gujarati ----
  { keys: ["undhiyu"], kcal: 145, carbs: 14, protein: 4, fat: 8.5, fiber: 4.5, sugars: 3, satFat: 1.3 },
  { keys: ["khandvi"], kcal: 150, carbs: 16, protein: 5, fat: 7.5, fiber: 1, sugars: 2, satFat: 1 },
  { keys: ["thepla"], kcal: 300, carbs: 42, protein: 7, fat: 11, fiber: 3.5, sugars: 1, satFat: 3 },
  { keys: ["fafda"], kcal: 400, carbs: 40, protein: 8, fat: 23, fiber: 2, sugars: 1, satFat: 4 },
  { keys: ["gujarati kadhi", "kadhi"], kcal: 90, carbs: 8, protein: 3, fat: 5, fiber: 0.5, sugars: 5, satFat: 2.8 },
  { keys: ["handvo"], kcal: 210, carbs: 26, protein: 6, fat: 9, fiber: 2, sugars: 2, satFat: 1.3 },
  { keys: ["gujarati dal", "sweet dal"], kcal: 120, carbs: 17, protein: 6.5, fat: 3, fiber: 4, sugars: 5, satFat: 0.5 },

  // ---- Maharashtrian ----
  { keys: ["misal pav"], kcal: 230, carbs: 26, protein: 8, fat: 10, fiber: 4, sugars: 3, satFat: 1.5 },
  { keys: ["vada pav"], kcal: 290, carbs: 38, protein: 6, fat: 13, fiber: 2.5, sugars: 2, satFat: 2 },
  { keys: ["puran poli"], kcal: 320, carbs: 55, protein: 7, fat: 8, fiber: 3, sugars: 22, satFat: 3.5 },
  { keys: ["thalipeeth"], kcal: 260, carbs: 34, protein: 7, fat: 10, fiber: 4, sugars: 1, satFat: 1.5 },
  { keys: ["kolhapuri chicken", "chicken kolhapuri"], kcal: 210, carbs: 6, protein: 17, fat: 14, fiber: 1.5, sugars: 2, satFat: 4.5 },
  { keys: ["sabudana khichdi"], kcal: 200, carbs: 30, protein: 3, fat: 8, fiber: 1, sugars: 1, satFat: 1 },

  // ---- More Punjabi / North Indian ----
  { keys: ["amritsari kulcha", "kulcha"], kcal: 320, carbs: 48, protein: 8, fat: 11, fiber: 2, sugars: 2, satFat: 4 },
  { keys: ["chole bhature"], kcal: 280, carbs: 32, protein: 8, fat: 13, fiber: 4, sugars: 3, satFat: 4.5 },
  { keys: ["makki di roti"], kcal: 250, carbs: 45, protein: 5, fat: 6, fiber: 4, sugars: 1, satFat: 1 },
  { keys: ["sarson da saag"], kcal: 95, carbs: 6, protein: 4, fat: 6, fiber: 3, sugars: 1.5, satFat: 2 },
  { keys: ["dal fry"], kcal: 130, carbs: 16, protein: 7, fat: 4.5, fiber: 4, sugars: 1.5, satFat: 1 },
  { keys: ["paneer tikka"], kcal: 220, carbs: 5, protein: 14, fat: 16, fiber: 1, sugars: 2, satFat: 8 },
  { keys: ["malai kofta"], kcal: 260, carbs: 12, protein: 6, fat: 21, fiber: 1.5, sugars: 5, satFat: 9 },
  { keys: ["rogan josh"], kcal: 225, carbs: 5, protein: 18, fat: 15, fiber: 0.8, sugars: 2, satFat: 5.5 },

  // ---- More snacks / breakfast ----
  { keys: ["aloo tikki"], kcal: 210, carbs: 26, protein: 3.5, fat: 10, fiber: 2.5, sugars: 1.5, satFat: 1.5 },
  { keys: ["kachori"], kcal: 300, carbs: 32, protein: 6, fat: 17, fiber: 2.5, sugars: 1, satFat: 3.5 },
  { keys: ["dabeli"], kcal: 260, carbs: 38, protein: 5, fat: 10, fiber: 2.5, sugars: 6, satFat: 1.8 },
  { keys: ["upma rava"], kcal: 140, carbs: 20, protein: 3.5, fat: 5, fiber: 1.5, sugars: 0.5, satFat: 0.7 },
  { keys: ["besan chilla", "chilla"], kcal: 140, carbs: 14, protein: 6.5, fat: 6.5, fiber: 3, sugars: 1.5, satFat: 0.7 },
  { keys: ["parotta", "kerala parotta", "malabar paratha"], kcal: 340, carbs: 44, protein: 6, fat: 15, fiber: 1.5, sugars: 1, satFat: 5.5 },

  // ---- More sweets ----
  { keys: ["kaju katli"], kcal: 460, carbs: 55, protein: 9, fat: 24, fiber: 1.5, sugars: 40, satFat: 5.5 },
  { keys: ["soan papdi"], kcal: 440, carbs: 60, protein: 5, fat: 20, fiber: 0.5, sugars: 42, satFat: 6.5 },
  { keys: ["modak"], kcal: 210, carbs: 32, protein: 3.5, fat: 8, fiber: 2, sugars: 20, satFat: 4 },
  { keys: ["shrikhand"], kcal: 210, carbs: 30, protein: 6, fat: 7.5, fiber: 0, sugars: 27, satFat: 4.8 },

  // ---- Generic building blocks (used when a more specific dish isn't matched) ----
  { keys: ["ghee", "clarified butter"], kcal: 900, carbs: 0, protein: 0, fat: 100, fiber: 0, sugars: 0, satFat: 62 },
  { keys: ["cooking oil", "vegetable oil", "mustard oil"], kcal: 884, carbs: 0, protein: 0, fat: 100, fiber: 0, sugars: 0, satFat: 13 },
  { keys: ["onion"], kcal: 40, carbs: 9.3, protein: 1.1, fat: 0.1, fiber: 1.7, sugars: 4.2, satFat: 0 },
  { keys: ["tomato"], kcal: 18, carbs: 3.9, protein: 0.9, fat: 0.2, fiber: 1.2, sugars: 2.6, satFat: 0 },
  { keys: ["potato", "aloo"], kcal: 87, carbs: 20, protein: 1.9, fat: 0.1, fiber: 2.2, sugars: 0.9, satFat: 0 },
  { keys: ["cauliflower", "gobi"], kcal: 25, carbs: 5, protein: 2, fat: 0.3, fiber: 2, sugars: 1.9, satFat: 0 },
  { keys: ["spinach", "palak"], kcal: 23, carbs: 3.6, protein: 2.9, fat: 0.4, fiber: 2.2, sugars: 0.4, satFat: 0.1 },
  { keys: ["moong sprouts", "sprouts"], kcal: 105, carbs: 19, protein: 7, fat: 0.6, fiber: 4.5, sugars: 4, satFat: 0.1 },
  { keys: ["brinjal", "eggplant", "baingan"], kcal: 25, carbs: 6, protein: 1, fat: 0.2, fiber: 3, sugars: 3.5, satFat: 0 },
  { keys: ["capsicum", "bell pepper", "shimla mirch"], kcal: 20, carbs: 4.6, protein: 0.9, fat: 0.2, fiber: 1.7, sugars: 2.4, satFat: 0 },
  { keys: ["green peas", "matar"], kcal: 81, carbs: 14, protein: 5.4, fat: 0.4, fiber: 5, sugars: 5.7, satFat: 0.1 },
  { keys: ["coconut", "grated coconut"], kcal: 354, carbs: 15, protein: 3.3, fat: 33, fiber: 9, sugars: 6, satFat: 30 },
  { keys: ["boondi"], kcal: 480, carbs: 42, protein: 9, fat: 30, fiber: 1.5, sugars: 5, satFat: 5 },
];

function normalize(str) {
  return (str || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}

/**
 * Look up an ingredient/dish component name against the curated Indian
 * food DB. Returns a per-100g nutrition object or null if no reasonable
 * match is found. Matching is keyword-based: an entry matches if any of
 * its keys appears as a substring of the normalized query, preferring
 * the longest (most specific) key match across all entries.
 */
function lookupIndianFood(name) {
  const q = normalize(name);
  if (!q) return null;

  let best = null;
  let bestLen = 0;

  for (const entry of INDIAN_FOOD_DB) {
    for (const key of entry.keys) {
      if (q.includes(key) && key.length > bestLen) {
        best = entry;
        bestLen = key.length;
      }
    }
  }

  if (!best) return null;
  const { kcal, carbs, protein, fat, fiber, sugars, satFat } = best;
  return { kcal, carbs, protein, fat, fiber, sugars, satFat };
}

module.exports = { lookupIndianFood, INDIAN_FOOD_DB };
