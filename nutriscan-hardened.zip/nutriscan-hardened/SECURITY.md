# Security notes

This document summarizes the security hardening applied to NutriScan's
`/api/analyse` endpoint and how to maintain it going forward.

## 1. Rate limiting

`api/_lib/rate-limit.js` adds an in-memory, sliding-window limiter applied
in `api/analyse.js`:

- **Burst limit:** 5 requests/minute per IP — stops scripted rapid-fire abuse.
- **Sustained limit:** 60 requests/hour per IP — stops slow-and-steady quota draining.

Every response includes standard `RateLimit-*` headers; requests over the
limit get an HTTP `429` with a `Retry-After` header and a friendly error
message, without ever reaching the (billed) NVIDIA/USDA API calls.

**Caveat:** this store is per-serverless-instance and in-memory, which is
a reasonable default for a small app but not perfectly consistent under
high concurrency across many warm instances. For strict, platform-wide
guarantees, back `store` in `rate-limit.js` with a shared store (Vercel KV,
Upstash Redis, etc.) — the `applyRateLimit()` call sites don't need to change.

## 2. Input validation & sanitization

`api/_lib/validate.js` enforces, before any downstream processing:

- Request body must be a JSON object with **only** the `image` field —
  any unexpected/extra field is rejected outright (400).
- `image` must be a string, within size bounds (~100B–8MB of base64 text),
  valid base64, and its decoded header must match a real JPEG/PNG/WebP
  magic-byte signature (not just a client-declared content-type).
- Downstream, the VLM's own JSON output (component names, gram estimates,
  barcode, product guess) is also bounded/clamped before being used in
  further API calls or lookups — defense in depth against an adversarial
  image coaxing unusual values out of the model.

Invalid requests return a `400` with a specific, actionable error message
and never reach the NVIDIA API call.

## 3. API key handling

- Both API keys (`NVIDIA_API_KEY`, `USDA_FDC_API_KEY`) are read exclusively
  from environment variables — never hard-coded, never sent to or
  readable from the client. The frontend (`index.html`) only ever calls
  our own `/api/analyse` endpoint; it has no knowledge of either key.
- `.env.example` documents the required variables without real values.
- `.gitignore` excludes `.env*` files from version control.

### Rotating a key

If a key is ever exposed (committed to git, logged, leaked, etc.), rotate
it immediately — do not just delete it from the code:

1. **NVIDIA:** go to https://build.nvidia.com, revoke the compromised key
   under your account's API keys page, generate a new one.
2. **USDA FDC:** go to https://api.data.gov/signup (or your account's key
   management page) to reissue.
3. Update the environment variable in your hosting platform (Vercel →
   Project → Settings → Environment Variables) with the new value and
   redeploy.
4. If the leaked key was committed to git history, treat the repo history
   itself as compromised — scrub it (e.g. `git filter-repo`) in addition
   to rotating, since revoking the key alone doesn't remove it from history.

## What was intentionally left unchanged

- The Open Food Facts and USDA calls remain unauthenticated/public-data
  reads (OFF requires no key; USDA falls back to the public `DEMO_KEY`
  tier if `USDA_FDC_API_KEY` isn't set) — these are read-only, low-risk,
  and rate-limiting the outer `/api/analyse` endpoint already bounds how
  often they're reached.
- CORS remains `Access-Control-Allow-Origin: *` since this is a public,
  unauthenticated tool with no user-specific data — tightening this to a
  specific origin is a reasonable follow-up if the app moves off a single
  known domain.
