// ─────────────────────────────────────────────────────────────────────────
// NutriScan API — vision model (NVIDIA) + Open Food Facts grounding
//
// Flow:
//   1. Ask the VLM a SMALL question first: is this a packaged/labelled
//      product or a homemade/plated meal? If packaged, also try to read a
//      barcode and/or product name off the pack.
//   2a. CASE A (packaged): look the product up in Open Food Facts by
//       barcode, then by name search if no barcode/no match. If found,
//       build the result directly from real database numbers — no VLM
//       nutrition guessing involved. Only fall back to the old
//       "VLM reads the label" flow if Open Food Facts has nothing.
//   2b. CASE B (homemade/restaurant): no barcode database can help here.
//       Ask the VLM to decompose the dish into ingredients + estimated
//       grams, then compute nutrition per-ingredient using Open Food
//       Facts generic entries where possible, falling back to the VLM's
//       own estimate for ingredients it can't find. This is more
//       consistent than asking for one big guessed number.
// ─────────────────────────────────────────────────────────────────────────

const { lookupIndianFood } = require("./indian-food-db");
const { lookupWorldFood } = require("./world-food-db");
const { lookupUsdaFood } = require("./usda-food-db");
const { applyRateLimit } = require("./_lib/rate-limit");
const { ValidationError, validateImageBase64, assertNoUnexpectedFields } = require("./_lib/validate");

const OFF_BASE = "https://world.openfoodfacts.org/api/v2";
const OFF_SEARCH = "https://world.openfoodfacts.org/api/v2/search";
const OFF_HEADERS = {
  "User-Agent": "NutriScan/1.0 (contact: nutriscan-app@example.com)"
};

// ---------------------------------------------------------------------------
// Open Food Facts helpers
// ---------------------------------------------------------------------------

async function offFetchByBarcode(barcode, timeoutMs = 6000) {
  if (!barcode) return null;
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const url = `${OFF_BASE}/product/${encodeURIComponent(barcode)}.json?fields=product_name,brands,quantity,serving_size,nutriments,ingredients_text,nova_group,nutrition_grades`;
    const r = await fetch(url, { headers: OFF_HEADERS, signal: controller.signal });
    if (!r.ok) return null;
    const data = await r.json();
    if (data.status !== 1 || !data.product) return null;
    return data.product;
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

// Common Indian packaged-food brand names — used as one signal (alongside
// the barcode's GS1 country prefix) to decide whether it's worth also
// checking Open Food Facts' India-scoped listings for a product. This is
// NOT used to gate ranking correctness, only to decide whether an extra
// scoped search is worth trying.
const INDIAN_BRAND_HINTS = /\b(parle|britannia|haldiram|amul|mtr|bikaji|patanjali|itc|tata|everest|mdh|balaji|bingo|kurkure|lehar|priya gold|sunfeast|bikanervala|dabur|catch|aashirvaad|fortune|saffola|gits|nirav|badshah)\b/i;

// India's GS1 barcode country-code prefix range is 890.
function isIndianBarcode(barcode) {
  return typeof barcode === "string" && /^890/.test(barcode.trim());
}

// Score how well a candidate OFF product actually matches the searched
// name, using word-overlap rather than trusting the search engine's
// ranking or popularity alone. This is what stops an unrelated-but-heavily
// -scanned product (e.g. Parle-G) from winning just because a scoped
// search returned it as a loose fuzzy match for an unrelated query
// (e.g. "Snickers").
function nameMatchScore(query, product) {
  const norm = (s) => (s || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter(w => w.length > 1);
  const qWords = new Set(norm(query));
  if (!qWords.size) return 0;
  const candidateText = `${product.product_name || ""} ${product.brands || ""}`;
  const cWords = new Set(norm(candidateText));
  let overlap = 0;
  for (const w of qWords) if (cWords.has(w)) overlap++;
  return overlap / qWords.size; // 0..1, fraction of query words found in the candidate
}

async function offSearchByName(name, timeoutMs = 6000, indiaHint = false) {
  if (!name) return null;
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const best = await tryOffSearch(name, indiaHint, controller);
    if (best) return best;

    // The full guessed name (e.g. "Snickers Original 50g") can search
    // worse than just the brand/product word alone, especially when the
    // model appended a size/variant that isn't in OFF's indexed text
    // for that product. Retry once with just the first significant word
    // before giving up and falling back to VLM label reading.
    const firstWord = (name.match(/[a-zA-Z][a-zA-Z'-]{2,}/) || [])[0];
    if (firstWord && firstWord.toLowerCase() !== name.toLowerCase()) {
      return await tryOffSearch(firstWord, indiaHint, controller);
    }
    return null;
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

async function tryOffSearch(name, indiaHint, controller) {
  const globalUrl = `${OFF_SEARCH}?search_terms=${encodeURIComponent(name)}&page_size=8&fields=product_name,brands,quantity,serving_size,nutriments,ingredients_text,nova_group,nutrition_grades,unique_scans_n`;
  const r = await fetch(globalUrl, { headers: OFF_HEADERS, signal: controller.signal });
  if (!r.ok) return null;
  const data = await r.json();
  let products = (data.products || []).filter(p => p.nutriments && p.nutriments["energy-kcal_100g"] != null);

  // Only bother with an India-scoped search when there's an actual signal
  // the product is Indian (barcode prefix or a recognized Indian brand
  // name) — Open Food Facts' global search already covers Indian
  // products that are well-represented there, and unconditionally
  // scoping every lookup to India is exactly what broke Snickers.
  if (indiaHint) {
    const indiaUrl = `${OFF_SEARCH}?search_terms=${encodeURIComponent(name)}&countries_tags=en:india&page_size=8&fields=product_name,brands,quantity,serving_size,nutriments,ingredients_text,nova_group,nutrition_grades,unique_scans_n`;
    const rIndia = await fetch(indiaUrl, { headers: OFF_HEADERS, signal: controller.signal });
    if (rIndia.ok) {
      const dataIndia = await rIndia.json();
      const indiaProducts = (dataIndia.products || []).filter(p => p.nutriments && p.nutriments["energy-kcal_100g"] != null);
      products = products.concat(indiaProducts);
    }
  }

  if (!products.length) return null;

  // Rank by actual name/brand similarity to the query first; use scan
  // count only to break ties between similarly-good matches. This is the
  // key fix — popularity alone (the old behavior) let an unrelated but
  // heavily-scanned product outrank a genuine match, or worse, "win" when
  // there was no genuine match in the result set at all.
  const scored = products.map(p => ({ p, score: nameMatchScore(name, p) }));
  scored.sort((a, b) => b.score - a.score || (b.p.unique_scans_n || 0) - (a.p.unique_scans_n || 0));

  const best = scored[0];
  // Require at least one real word of overlap. Below that, we don't have
  // a genuine match — return null so the caller falls back to the VLM
  // reading the label directly, which is far more reliable than guessing.
  if (!best || best.score < 0.34) return null;
  return best.p;
}

// Convert an Open Food Facts product (per-100g nutriments) into our
// response shape, scaled to a chosen serving size in grams.
function buildResultFromOFF(product, servingGrams, servingNote) {
  const n = product.nutriments || {};
  const per100 = (key) => {
    const v = n[`${key}_100g`];
    return typeof v === "number" ? v : 0;
  };

  const scale = servingGrams / 100;
  const kcal100 = n["energy-kcal_100g"];
  const calories = Math.round((typeof kcal100 === "number" ? kcal100 : 0) * scale);
  const carbs = +(per100("carbohydrates") * scale).toFixed(1);
  const protein = +(per100("proteins") * scale).toFixed(1);
  const fat = +(per100("fat") * scale).toFixed(1);
  const fiber = +(per100("fiber") * scale).toFixed(1);
  const sugars = per100("sugars") * scale;
  const satFat = per100("saturated-fat") * scale;
  const sodium = per100("sodium") * scale * 1000; // g -> mg

  const kcalFromMacros = carbs * 4 + protein * 4 + fat * 9;
  const finalCalories = calories > 0 ? calories : Math.round(kcalFromMacros);

  const pct = (grams, kcalPerG) =>
    finalCalories > 0 ? Math.round((grams * kcalPerG * 100) / finalCalories) : 0;

  const tags = [];
  if (sugars >= 15) tags.push({ label: "high in sugar", type: "red" });
  else if (sugars >= 5) tags.push({ label: "moderate sugar", type: "yellow" });
  if (satFat >= 5) tags.push({ label: "high in saturated fat", type: "red" });
  if (fiber >= 5) tags.push({ label: "high in fiber", type: "green" });
  if (protein >= 10) tags.push({ label: "good protein source", type: "green" });
  if (sodium >= 600) tags.push({ label: "high sodium", type: "red" });
  if (product.nova_group === 4) tags.push({ label: "ultra-processed", type: "red" });

  const ingredientsList = product.ingredients_text
    ? product.ingredients_text.split(",").map(s => s.trim()).filter(Boolean).slice(0, 15)
    : [];

  // Open Food Facts micronutrient fields are voluntary — most products
  // (especially confectionery/snacks) simply don't have them entered, so
  // this will often legitimately come back empty. When present, surface
  // them rather than discarding them, scaled to the same serving size as
  // everything else.
  const MICRO_FIELDS = [
    { key: "vitamin-a", label: "Vitamin A", unit: "µg" },
    { key: "vitamin-c", label: "Vitamin C", unit: "mg" },
    { key: "vitamin-d", label: "Vitamin D", unit: "µg" },
    { key: "vitamin-e", label: "Vitamin E", unit: "mg" },
    { key: "vitamin-b12", label: "Vitamin B12", unit: "µg" },
    { key: "calcium", label: "Calcium", unit: "mg" },
    { key: "iron", label: "Iron", unit: "mg" },
    { key: "magnesium", label: "Magnesium", unit: "mg" },
    { key: "potassium", label: "Potassium", unit: "mg" },
    { key: "zinc", label: "Zinc", unit: "mg" }
  ];
  const vitaminsMinerals = MICRO_FIELDS
    .map(({ key, label, unit }) => {
      const v = n[`${key}_100g`];
      if (typeof v !== "number" || v <= 0) return null;
      // OFF stores these values in grams internally regardless of display
      // unit for some fields (notably vitamin-a/d in µg equiv. as grams,
      // minerals in grams) — normalize mg/µg fields that are unrealistically
      // tiny as raw grams by converting, since a value like 0.0009 is g not mg.
      const scaled = v * scale;
      const displayVal = unit === "µg" ? scaled * 1e6 : scaled * 1000;
      if (!isFinite(displayVal) || displayVal <= 0) return null;
      return { name: label, amount: `${displayVal < 10 ? displayVal.toFixed(1) : Math.round(displayVal)}${unit}` };
    })
    .filter(Boolean);

  // Simple deterministic health score from Nutri-Score grade when present,
  // otherwise derived from sugar/fat/fiber/protein balance.
  let healthScore;
  const grade = (product.nutrition_grades || "").toLowerCase();
  const gradeScore = { a: 90, b: 72, c: 54, d: 36, e: 18 }[grade];
  if (gradeScore != null) {
    healthScore = gradeScore;
  } else {
    healthScore = 60;
    healthScore -= Math.min(30, sugars);
    healthScore -= Math.min(20, satFat * 2);
    healthScore += Math.min(15, fiber * 2);
    healthScore += Math.min(15, protein);
    healthScore = Math.max(1, Math.min(100, Math.round(healthScore)));
  }

  return {
    food_name: product.product_name || "Packaged food",
    category: (product.brands || "Packaged food").split(",")[0].trim(),
    data_source: "database",
    serving_note: servingNote,
    estimated_grams: servingGrams,
    score_formula: "off",
    confidence: "high",
    confidence_reasons: [],
    grade: grade || null,
    raw_totals: {
      sugars: +sugars.toFixed(2),
      satFat: +satFat.toFixed(2),
      sodium: +sodium.toFixed(1)
    },
    calories: finalCalories,
    macros: {
      carbs: { grams: carbs, pct: pct(carbs, 4) },
      protein: { grams: protein, pct: pct(protein, 4) },
      fat: { grams: fat, pct: pct(fat, 9) },
      fiber: { grams: fiber, pct: pct(fiber, 2) }
    },
    ingredients: ingredientsList,
    vitamins_minerals: vitaminsMinerals,
    health_score: healthScore,
    health_tags: tags,
    insight: `Nutrition figures sourced from Open Food Facts' product database rather than estimated from the photo, so they should closely match the printed label.${!ingredientsList.length ? " This product's ingredient list wasn't available in the database." : ""}${!vitaminsMinerals.length ? " Vitamin/mineral data wasn't submitted for this product in the database (this is common for confectionery and snacks, which aren't required to disclose it)." : ""}`
  };
}

// ---------------------------------------------------------------------------
// NVIDIA VLM helpers (largely unchanged from the original implementation)
// ---------------------------------------------------------------------------

const extractRetryDelay = (errBody, message, headers) => {
  const retryAfterHeader = headers?.get?.("retry-after");
  if (retryAfterHeader) {
    const secs = parseFloat(retryAfterHeader);
    if (!isNaN(secs)) return secs;
  }
  const m = /retry in ([\d.]+)s/i.exec(message || "");
  if (m) return parseFloat(m[1]);
  return null;
};

const isKimi = (model) => model.startsWith("moonshotai/");
const modelPlan = ["nvidia/nemotron-nano-12b-v2-vl", "moonshotai/kimi-k2.6"];
const timeoutFor = (model) => (isKimi(model) ? 35000 : 15000);

function buildBody(model, promptText, imageBase64) {
  if (isKimi(model)) {
    return {
      model,
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: promptText },
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } }
          ]
        }
      ],
      thinking: { type: "disabled" },
      max_tokens: 4096,
      stream: false
    };
  }
  return {
    model,
    messages: [
      { role: "system", content: "/no_think" },
      {
        role: "user",
        content: [
          { type: "text", text: promptText },
          { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } }
        ]
      }
    ],
    temperature: 0.15,
    top_p: 0.9,
    max_tokens: 1536,
    stream: false
  };
}

async function callNvidia(model, promptText, imageBase64, nvidiaKey, timeoutMs) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  const body = buildBody(model, promptText, imageBase64);

  try {
    const nRes = await fetch("https://integrate.api.nvidia.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${nvidiaKey}`,
        "Accept": "application/json"
      },
      signal: controller.signal,
      body: JSON.stringify(body)
    });

    clearTimeout(timeout);

    if (!nRes.ok) {
      const errBody = await nRes.json().catch(() => ({}));
      const msg = errBody.error?.message || errBody.message || `NVIDIA API error ${nRes.status}`;
      const err = new Error(msg);
      err.status = nRes.status;
      err.retryDelaySeconds = extractRetryDelay(errBody, msg, nRes.headers);
      throw err;
    }

    const data = await nRes.json();
    const choice = data.choices?.[0];

    if (choice?.finish_reason === "length") {
      const err = new Error("Response was cut off before completing.");
      err.retryableTruncation = true;
      throw err;
    }
    if (choice?.finish_reason === "content_filter") {
      throw new Error("The model declined to analyse this image. Try a clearer, well-lit photo.");
    }

    let raw = choice?.message?.content || "";
    raw = raw.replace(/<think>[\s\S]*?<\/think>/gi, "");
    return raw.trim();
  } finally {
    clearTimeout(timeout);
  }
}

const isQuotaExhausted = (e) => e.status === 429 || /quota|rate.?limit|resource_exhausted/i.test(e.message || "");
const isQuickRetryable = (e) =>
  e.name === "AbortError" ||
  e.status === 502 ||
  e.status === 503 ||
  e.retryableTruncation === true ||
  /overload|unavailable/i.test(e.message || "");

// Runs the model plan (Nemotron -> Kimi, with one retry each) for a given
// prompt/image pair and returns cleaned raw text, or throws.
async function runModelPlan(promptText, imageBase64, nvidiaKey) {
  let raw = "";
  let lastError = "";
  let waitEtaSeconds = null;

  outer:
  for (const model of modelPlan) {
    const callTimeout = timeoutFor(model);
    try {
      raw = await callNvidia(model, promptText, imageBase64, nvidiaKey, callTimeout);
      if (raw) break outer;
    } catch (e) {
      lastError = e.message;
      console.log(`nvidia:${model} failed:`, e.message);
      if (isQuotaExhausted(e)) {
        waitEtaSeconds = e.retryDelaySeconds;
        continue;
      }
      if (isQuickRetryable(e)) {
        try {
          raw = await callNvidia(model, promptText, imageBase64, nvidiaKey, callTimeout);
          if (raw) break outer;
        } catch (e2) {
          lastError = e2.message;
          console.log(`nvidia:${model} retry failed:`, e2.message);
        }
      }
    }
  }

  if (!raw) {
    let eta = "";
    if (waitEtaSeconds) {
      eta = waitEtaSeconds < 60
        ? ` Try again in about ${Math.ceil(waitEtaSeconds)} seconds.`
        : ` Try again in about ${Math.ceil(waitEtaSeconds / 60)} minute(s).`;
    }
    throw new Error((lastError || "No response from NVIDIA API") + eta);
  }

  return raw;
}

function parseJsonFromRaw(raw) {
  let cleaned = raw
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();

  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1) {
    const err = new Error("The model didn't return the expected data. Please try again.");
    err.badJson = true;
    throw err;
  }
  try {
    return JSON.parse(cleaned.substring(start, end + 1));
  } catch {
    const err = new Error("The model's response was malformed. Please try again.");
    err.badJson = true;
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Step 1 prompt: cheap triage — packaged vs. homemade, plus whatever
// identifying info (barcode / product name, or dish + ingredients) is
// visible. Kept small on purpose so it's fast.
// ---------------------------------------------------------------------------

const TRIAGE_PROMPT = `Look at this food photo and decide which case applies.

CASE A — PACKAGED/LABELLED FOOD: a packet, wrapper, box, or printed nutrition label, with or without a visible barcode.
CASE B — HOMEMADE/RESTAURANT/LOOSE FOOD: a plated meal or dish with no packaging.

For CASE A: read the barcode digits if one is visible (else null), and give your best guess of the exact product name and brand as printed on the pack (be specific, e.g. "Snickers Original 50g" not just "chocolate bar").

For CASE B, portion weight is the part you are most likely to get wrong, so be deliberate about it:
1. First, find a size reference already in the shot — a standard dinner plate (~26-28cm), a side plate (~18-20cm), a bowl, cutlery, a hand, a drink can/cup — and use it to judge scale. If a plate is visible, explicitly estimate what fraction of the plate's diameter and area the food occupies before converting to grams; this is more reliable than judging absolute size directly. Note briefly to yourself how full the plate/bowl looks and how high the food is piled, then convert that to grams. If nothing in the photo gives you scale, default to a typical single-person restaurant/home serving for that dish rather than guessing large.
2. Cross-check: does your total gram estimate match a realistic single-person portion for this dish (most home meals are 250-500g total, not 700g+, unless the plate is visibly stacked or it's clearly for sharing)? If your estimate is unusually high or low for the dish type, reconsider it.
3. Break the dish into ONLY its main visible components — normally 2-5. Do not split out small garnishes, individual spices, or trace amounts of oil/herbs as their own component; fold them into the component they belong to (e.g. tempering oil stays part of the dal, not its own line item). Component grams should roughly sum to the total.
4. For protein-dense components specifically (meat, fish, egg, paneer, tofu, legumes) — these drive most of the protein total, so get their gram estimate right individually rather than lumping them into a vague "meal total." Use known real-world references: one large egg ≈ 50g, one standard breakfast sausage ≈ 50-70g, one rasher of bacon ≈ 15-20g, a deck-of-cards-sized piece of meat/fish ≈ 100g, a chicken breast ≈ 150-200g, a palm-sized paneer/tofu portion ≈ 100g. Count visible units where possible (e.g. "2 eggs" = 2×50g, not one blended estimate) rather than eyeballing a single combined weight.
5. If the dish looks Indian or South Asian, use the common Indian name for the dish and each component (e.g. "chana masala" not "chickpea stew", "aloo paratha" not "stuffed flatbread", "dal" not "lentil soup", "basmati rice" not just "rice") — this matters for matching against a curated Indian food nutrition database. For other cuisines, use the specific common name for the dish (e.g. "spaghetti bolognese", "chicken burrito", "pad thai") rather than a generic description, for the same reason.

Reply with ONLY raw JSON, no markdown fences, no commentary:
{"case": "A"|"B",
 "barcode": string|null,
 "product_guess": string|null,
 "dish_name": string|null,
 "total_grams": number|null,
 "portion_reference": string|null,
 "components": [{"name": string, "grams": number}]|null}`;

// Fallback prompt for Case A when Open Food Facts has no match. Handles
// two different photo situations, since they need different strategies:
//   (a) the nutrition table IS visible — transcribe it exactly, digit by
//       digit, and don't estimate.
//   (b) only the FRONT of the pack is visible (brand/logo/product shot,
//       no nutrition panel) — this is common for hero/marketing photos
//       and is NOT a barcode problem, it's simply that the numbers aren't
//       in the frame. In that case, identify the specific product by name
//       and use well-established public nutrition facts for it (the kind
//       printed on virtually every pack of that product) rather than
//       failing outright — but say clearly that this is recalled, not
//       read from this specific photo.
function labelReadingPrompt() {
  return `You are a food nutrition expert analysing a real photo of a packaged food product. First check: is a nutrition facts table/panel actually visible and legible in this photo?

IF A NUTRITION TABLE IS VISIBLE: Locate it and READ THE PRINTED DIGITS EXACTLY, character by character — do not round, do not estimate, do not substitute a typical value for this food category. If the label shows both "per 100g" and "per serving/pack" columns, use the PER SERVING column (state which serving size in "serving_note"); if only one column exists, use that one and say so. Use the ingredient list printed on the pack for "ingredients" if visible. Set "data_source" to "label".

IF NO NUTRITION TABLE IS VISIBLE (e.g. this is a front-of-pack product/marketing shot with no visible nutrition panel): do NOT fail or refuse. Instead, identify the specific product as precisely as you can from the branding, logo, and packaging shown (e.g. "Snickers Original", "Lay's Classic 52g", "Parle-G"), and provide the well-known standard nutrition facts for that exact product and its typical single-pack/single-bar serving size, based on what is commonly printed on that product's packaging. Set "data_source" to "label" still, but set "confidence" to "medium" and include in "confidence_reasons" that these values are recalled for this known product rather than read from this specific photo, since no nutrition panel was visible in frame. This is unrelated to barcodes — whether or not a barcode is visible does not affect this step.

Only if you genuinely cannot identify the product at all (illegible, generic, or unbranded packaging with no visible nutrition information) should you decline — and even then, still return your best-guess food_name and a rough calorie estimate for that category of food rather than an empty response.

Before finalizing, sanity-check your own numbers: carbs_g×4 + protein_g×4 + fat_g×9 should land within ~15% of the stated calories. If it does not, re-examine and correct it.

Reply with ONLY a raw JSON object matching this exact shape — no markdown fences, no commentary, no <think> tags, start with { and end with }:
{"food_name": string, "category": string, "data_source": "label", "serving_note": string, "calories": integer, "confidence": "high"|"medium"|null, "confidence_reasons": [string]|null, "macros": {"carbs": {"grams": number, "pct": integer}, "protein": {"grams": number, "pct": integer}, "fat": {"grams": number, "pct": integer}, "fiber": {"grams": number, "pct": integer}}, "ingredients": [string, ...], "vitamins_minerals": [{"name": string, "amount": string}, ...], "health_score": integer, "health_tags": [{"label": string, "type": "green"|"yellow"|"red"}, ...], "insight": string}`;
}

// Fallback prompt for Case B ingredients that Open Food Facts couldn't
// resolve — ask the VLM directly for that one ingredient's per-100g
// macros, grounded in what it can see, rather than the whole dish at once.
function ingredientEstimatePrompt(name, grams) {
  return `Estimate typical nutrition per 100g for the food ingredient/component: "${name}" (as it appears prepared in this dish, e.g. cooked/oiled/seasoned if visible in the photo). Reply with ONLY raw JSON: {"kcal_100g": number, "carbs_100g": number, "protein_100g": number, "fat_100g": number, "fiber_100g": number}`;
}

// ---------------------------------------------------------------------------
// Case B: decompose into ingredients, resolve each against Open Food
// Facts generic entries, fall back to VLM per-ingredient estimate.
// ---------------------------------------------------------------------------

async function resolveIngredient(component, imageBase64, nvidiaKey) {
  const { name, grams } = component;
  const scale = grams / 100;

  // Tier 1: curated Indian food nutrition database. Checked first because
  // Open Food Facts is overwhelmingly packaged Western/European branded
  // products and has very poor coverage of generic Indian home-cooked
  // dishes (dals, sabzis, breads, curries) — searching it for "chana
  // masala" or "aloo paratha" tends to return nothing or a loose mismatch.
  const indianMatch = lookupIndianFood(name);
  if (indianMatch) {
    return {
      name,
      grams,
      source: "indian_db",
      kcal: indianMatch.kcal * scale,
      carbs: indianMatch.carbs * scale,
      protein: indianMatch.protein * scale,
      fat: indianMatch.fat * scale,
      fiber: indianMatch.fiber * scale,
      sugars: indianMatch.sugars * scale,
      satFat: indianMatch.satFat * scale
    };
  }

  // Tier 1b: curated general/world cuisine database (Italian, Mexican,
  // Chinese, American, Mediterranean, breakfast staples, etc). Same
  // rationale as the Indian DB — Open Food Facts has poor coverage of
  // prepared home-style dishes for these cuisines too.
  const worldMatch = lookupWorldFood(name);
  if (worldMatch) {
    return {
      name,
      grams,
      source: "world_db",
      kcal: worldMatch.kcal * scale,
      carbs: worldMatch.carbs * scale,
      protein: worldMatch.protein * scale,
      fat: worldMatch.fat * scale,
      fiber: worldMatch.fiber * scale,
      sugars: worldMatch.sugars * scale,
      satFat: worldMatch.satFat * scale
    };
  }

  // Tier 2: USDA FoodData Central — deep, government-verified coverage of
  // generic raw/prepared ingredients (Foundation Foods + SR Legacy) that
  // aren't specific enough to warrant a curated cuisine-DB entry (e.g. a
  // single ingredient like "chicken breast", "broccoli", "cheddar cheese",
  // or a simple preparation like "scrambled egg"). Free, public-domain,
  // ~400k entries. Checked before Open Food Facts because FDC's generic
  // foods are lab-analyzed and per-100g by construction, whereas OFF here
  // is mainly useful for packaged-style items with inconsistent serving
  // reporting.
  const usdaMatch = await lookupUsdaFood(name);
  if (usdaMatch) {
    const m = usdaMatch.micros || {};
    return {
      name,
      grams,
      source: "usda_db",
      kcal: usdaMatch.kcal * scale,
      carbs: usdaMatch.carbs * scale,
      protein: usdaMatch.protein * scale,
      fat: usdaMatch.fat * scale,
      fiber: usdaMatch.fiber * scale,
      sugars: usdaMatch.sugars * scale,
      satFat: usdaMatch.satFat * scale,
      micros: {
        calcium: (m.calcium || 0) * scale,
        iron: (m.iron || 0) * scale,
        potassium: (m.potassium || 0) * scale,
        magnesium: (m.magnesium || 0) * scale,
        zinc: (m.zinc || 0) * scale,
        vitaminC: (m.vitaminC || 0) * scale,
        vitaminA: (m.vitaminA || 0) * scale
      }
    };
  }

  // Tier 3: Open Food Facts generic search (useful for packaged-style
  // ingredients that do show up there, e.g. "cheese slice", "peanut butter")
  const offMatch = await offSearchByName(name);
  if (offMatch && offMatch.nutriments) {
    const n = offMatch.nutriments;
    return {
      name,
      grams,
      source: "database",
      kcal: (n["energy-kcal_100g"] || 0) * scale,
      carbs: (n["carbohydrates_100g"] || 0) * scale,
      protein: (n["proteins_100g"] || 0) * scale,
      fat: (n["fat_100g"] || 0) * scale,
      fiber: (n["fiber_100g"] || 0) * scale,
      sugars: (n["sugars_100g"] || 0) * scale,
      satFat: (n["saturated-fat_100g"] || 0) * scale
    };
  }

  // Tier 4: fall back to a small, focused VLM estimate for just this ingredient
  try {
    const raw = await runModelPlan(ingredientEstimatePrompt(name, grams), imageBase64, nvidiaKey);
    const est = parseJsonFromRaw(raw);
    const scale = grams / 100;
    return {
      name,
      grams,
      source: "visual_estimate",
      kcal: (est.kcal_100g || 0) * scale,
      carbs: (est.carbs_100g || 0) * scale,
      protein: (est.protein_100g || 0) * scale,
      fat: (est.fat_100g || 0) * scale,
      fiber: (est.fiber_100g || 0) * scale,
      sugars: 0,
      satFat: 0
    };
  } catch {
    // Last-resort neutral estimate so one bad ingredient doesn't kill the whole result
    return { name, grams, source: "fallback", kcal: grams * 1.5, carbs: grams * 0.2, protein: grams * 0.05, fat: grams * 0.05, fiber: 0, sugars: 0, satFat: 0 };
  }
}

async function buildResultForHomemade(triage, imageBase64, nvidiaKey) {
  // Defense in depth: the VLM's JSON output ultimately drives further
  // outbound API calls (Open Food Facts, USDA) and prompt text, so it is
  // treated as untrusted input even though it isn't directly attacker-
  // supplied — a crafted/adversarial image could still coax unusual
  // values out of the model. Bound string length and clamp numeric
  // ranges rather than trusting them verbatim.
  const sanitizeComponent = (c) => {
    const name = String(c?.name ?? "food").slice(0, 100).trim() || "food";
    let grams = Number(c?.grams);
    if (!Number.isFinite(grams) || grams <= 0) grams = 100;
    grams = Math.min(Math.max(grams, 1), 2000); // clamp to a sane single-component range
    return { name, grams };
  };

  const components = (triage.components || []).slice(0, 8).map(sanitizeComponent);
  if (!components.length) {
    // No breakdown available — treat whole dish as one "ingredient"
    components.push(sanitizeComponent({ name: triage.dish_name || "food", grams: triage.total_grams || 300 }));
  }

  const resolved = await Promise.all(components.map(c => resolveIngredient(c, imageBase64, nvidiaKey)));

  const totals = resolved.reduce((acc, r) => {
    acc.kcal += r.kcal; acc.carbs += r.carbs; acc.protein += r.protein;
    acc.fat += r.fat; acc.fiber += r.fiber; acc.sugars += r.sugars; acc.satFat += r.satFat;
    if (r.micros) {
      acc.micros.calcium += r.micros.calcium || 0;
      acc.micros.iron += r.micros.iron || 0;
      acc.micros.potassium += r.micros.potassium || 0;
      acc.micros.magnesium += r.micros.magnesium || 0;
      acc.micros.zinc += r.micros.zinc || 0;
      acc.micros.vitaminC += r.micros.vitaminC || 0;
      acc.micros.vitaminA += r.micros.vitaminA || 0;
    }
    return acc;
  }, { kcal: 0, carbs: 0, protein: 0, fat: 0, fiber: 0, sugars: 0, satFat: 0,
       micros: { calcium: 0, iron: 0, potassium: 0, magnesium: 0, zinc: 0, vitaminC: 0, vitaminA: 0 } });

  const calories = Math.round(totals.kcal);
  const pct = (grams, kcalPerG) => calories > 0 ? Math.round((grams * kcalPerG * 100) / calories) : 0;

  const tags = [];
  if (totals.sugars >= 15) tags.push({ label: "high in sugar", type: "red" });
  if (totals.satFat >= 5) tags.push({ label: "high in saturated fat", type: "red" });
  if (totals.fiber >= 5) tags.push({ label: "high in fiber", type: "green" });
  if (totals.protein >= 15) tags.push({ label: "rich in protein", type: "green" });

  let healthScore = 60;
  healthScore -= Math.min(30, totals.sugars);
  healthScore -= Math.min(20, totals.satFat * 2);
  healthScore += Math.min(15, totals.fiber * 2);
  healthScore += Math.min(15, totals.protein / 2);
  healthScore = Math.max(1, Math.min(100, Math.round(healthScore)));

  const indianDbCount = resolved.filter(r => r.source === "indian_db").length;
  const worldDbCount = resolved.filter(r => r.source === "world_db").length;
  const usdaDbCount = resolved.filter(r => r.source === "usda_db").length;
  const offDbCount = resolved.filter(r => r.source === "database").length;
  const guessedCount = resolved.filter(r => r.source === "visual_estimate" || r.source === "fallback").length;
  const curatedDbCount = indianDbCount + worldDbCount;
  const dbCount = curatedDbCount + usdaDbCount + offDbCount;
  const totalGrams = resolved.reduce((s, r) => s + r.grams, 0);

  // ---- Confidence scoring ----
  // Two independent checks: (1) how much of the nutrition came from real
  // database entries vs. the VLM guessing an ingredient's per-100g values
  // from scratch, and (2) whether the implied energy density (kcal per
  // gram of the whole plate) and total weight look like a plausible
  // single-serving meal. Either check failing lowers confidence — this
  // surfaces exactly the kind of bad estimate you ran into (e.g. an
  // inflated total gram figure) instead of presenting every result with
  // equal, unearned certainty.
  const reasons = [];
  let confidence = "high";

  if (guessedCount > 0) {
    reasons.push(`${guessedCount} of ${resolved.length} component(s) didn't match a nutrition database and were estimated by the AI from the photo alone`);
    confidence = guessedCount / resolved.length > 0.5 ? "low" : "medium";
  }

  const density = totalGrams > 0 ? calories / totalGrams : 0;
  if (density > 0 && (density < 0.3 || density > 4.5)) {
    reasons.push(`The implied energy density (${density.toFixed(1)} kcal/g) is unusual for a plate of food, which often means the estimated portion size is off`);
    confidence = confidence === "high" ? "medium" : "low";
  }

  if (totalGrams > 650 || totalGrams < 100) {
    reasons.push(`Estimated total weight (${Math.round(totalGrams)}g) is outside the typical single-serving range (roughly 150-550g) — worth checking with the portion adjuster`);
    confidence = confidence === "high" ? "medium" : "low";
  }

  const curatedParts = [];
  if (indianDbCount) curatedParts.push(`a curated Indian food nutrition database (${indianDbCount}/${resolved.length} components)`);
  if (worldDbCount) curatedParts.push(`a curated world-cuisine nutrition database (${worldDbCount}/${resolved.length} components)`);
  if (usdaDbCount) curatedParts.push(`USDA FoodData Central (${usdaDbCount}/${resolved.length} components)`);
  const curatedText = curatedParts.join(", ");

  const MICRO_DISPLAY = [
    { key: "calcium", label: "Calcium", unit: "mg" },
    { key: "iron", label: "Iron", unit: "mg" },
    { key: "potassium", label: "Potassium", unit: "mg" },
    { key: "magnesium", label: "Magnesium", unit: "mg" },
    { key: "zinc", label: "Zinc", unit: "mg" },
    { key: "vitaminC", label: "Vitamin C", unit: "mg" },
    { key: "vitaminA", label: "Vitamin A", unit: "µg" }
  ];
  const vitaminsMinerals = MICRO_DISPLAY
    .map(({ key, label, unit }) => {
      const v = totals.micros[key];
      if (!v || v <= 0) return null;
      return { name: label, amount: `${v < 10 ? v.toFixed(1) : Math.round(v)}${unit}` };
    })
    .filter(Boolean);

  return {
    food_name: triage.dish_name || "Homemade dish",
    category: "Homemade / restaurant",
    data_source: "visual_estimate",
    serving_note: `Estimated ${Math.round(totalGrams)}g total, based on ${resolved.length} identified component(s)`,
    estimated_grams: Math.round(totalGrams),
    score_formula: "homemade",
    confidence,
    confidence_reasons: reasons,
    raw_totals: {
      sugars: +totals.sugars.toFixed(2),
      satFat: +totals.satFat.toFixed(2)
    },
    calories,
    macros: {
      carbs: { grams: +totals.carbs.toFixed(1), pct: pct(totals.carbs, 4) },
      protein: { grams: +totals.protein.toFixed(1), pct: pct(totals.protein, 4) },
      fat: { grams: +totals.fat.toFixed(1), pct: pct(totals.fat, 9) },
      fiber: { grams: +totals.fiber.toFixed(1), pct: pct(totals.fiber, 2) }
    },
    ingredients: resolved.map(r => r.name),
    vitamins_minerals: vitaminsMinerals,
    health_score: healthScore,
    health_tags: tags,
    insight: `Estimated by breaking the dish into ${resolved.length} component(s) (${resolved.map(r => `${r.name} ~${Math.round(r.grams)}g`).join(", ")}) and pricing each against ${curatedText ? curatedText + (offDbCount ? ` plus ${offDbCount} from a general food database` : "") : dbCount ? "food database entries where available" : "typical nutrition values"}. Portion sizes are visual estimates — if the plate looks bigger or smaller than shown here, use the "adjust portion" control to rescale the numbers instantly.${!vitaminsMinerals.length ? " Vitamin/mineral data wasn't available for this dish's components (the curated cuisine databases track macros only)." : ""}${reasons.length ? ` ⚠️ ${reasons.join(". ")}.` : ""}`
  };
}

// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  // ---- Rate limiting (OWASP API4:2023 — Unrestricted Resource Consumption) ----
  // This endpoint triggers billed, comparatively expensive third-party VLM
  // calls, so it gets a stricter budget than a typical read endpoint.
  // Two layers: a short burst window (stops rapid-fire scripted abuse)
  // and a longer hourly window (stops sustained quota-draining abuse from
  // a single IP even if it paces itself under the burst limit).
  if (!applyRateLimit(req, res, { routeName: "analyse:burst", limit: 5, windowMs: 60 * 1000 })) return;
  if (!applyRateLimit(req, res, { routeName: "analyse:hourly", limit: 60, windowMs: 60 * 60 * 1000 })) return;

  try {
    // ---- Strict input validation (OWASP API3/ASVS 5.1) ----
    // Reject anything that isn't exactly { image: <base64 string> } —
    // no extra fields, no wrong types, no oversized or malformed payloads.
    let image;
    try {
      assertNoUnexpectedFields(req.body, ["image"]);
      if (!req.body || req.body.image == null) {
        return res.status(400).json({ error: "No image provided" });
      }
      image = validateImageBase64(req.body.image, "image");
    } catch (e) {
      if (e instanceof ValidationError) {
        return res.status(400).json({ error: e.message });
      }
      throw e;
    }

    const nvidiaKey = process.env.NVIDIA_API_KEY;
    if (!nvidiaKey) return res.status(500).json({ error: "NVIDIA API key not configured" });

    // ---- Step 1: triage ----
    const triageRaw = await runModelPlan(TRIAGE_PROMPT, image, nvidiaKey);
    let triage;
    try {
      triage = parseJsonFromRaw(triageRaw);
    } catch (e) {
      if (!e.badJson) throw e;
      // The model likely replied conversationally instead of with JSON
      // (common on packaging with glare/reflection or an unreadable
      // barcode). Ask once more with a stricter, more literal prompt
      // before giving up — this is the fix for photos that previously
      // failed outright with "Invalid response."
      const retryRaw = await runModelPlan(
        TRIAGE_PROMPT + `\n\nIMPORTANT: Reply with ONLY the JSON object shown above — no words before or after it, no explanation, no apology, even if you are uncertain. If you cannot read a barcode or exact product name, use your best visual guess and set that field's confidence implicitly by being as specific as the image allows, but always return valid JSON.`,
        image,
        nvidiaKey
      );
      triage = parseJsonFromRaw(retryRaw);
    }

    // ---- Case A: packaged food ----
    if (triage.case === "A") {
      let product = null;

      // Defense in depth: bound these before they flow into outbound
      // URLs (encodeURIComponent already prevents injection, but not
      // pathological length/type).
      if (triage.barcode != null) {
        triage.barcode = String(triage.barcode).replace(/[^0-9]/g, "").slice(0, 32) || null;
      }
      if (triage.product_guess != null) {
        triage.product_guess = String(triage.product_guess).slice(0, 150).trim() || null;
      }

      if (triage.barcode) {
        product = await offFetchByBarcode(triage.barcode);
      }
      if (!product && triage.product_guess) {
        const indiaHint = isIndianBarcode(triage.barcode) || INDIAN_BRAND_HINTS.test(triage.product_guess);
        product = await offSearchByName(triage.product_guess, 6000, indiaHint);
      }

      if (product) {
        // Prefer the product's own serving size if OFF has one and it parses
        // to a sane gram value; otherwise default to 100g and say so.
        let servingGrams = 100;
        let servingNote = "per 100g (Open Food Facts database)";
        const servingSizeStr = product.serving_size || "";
        const m = /([\d.]+)\s*g/i.exec(servingSizeStr);
        if (m) {
          servingGrams = parseFloat(m[1]);
          servingNote = `per serving (${servingSizeStr}, Open Food Facts database)`;
        }
        const result = buildResultFromOFF(product, servingGrams, servingNote);
        return res.status(200).json(result);
      }

      // No database match — fall back to the original label-reading VLM flow
      const raw = await runModelPlan(labelReadingPrompt(), image, nvidiaKey);
      let result;
      try {
        result = parseJsonFromRaw(raw);
      } catch (e) {
        if (!e.badJson) throw e;
        const retryRaw = await runModelPlan(
          labelReadingPrompt() + `\n\nIMPORTANT: Reply with ONLY the JSON object — no words before or after it, even if the label is partly unclear. Give your best reading rather than declining.`,
          image,
          nvidiaKey
        );
        result = parseJsonFromRaw(retryRaw);
      }
      if (!result.food_name || !result.calories) throw new Error("Incomplete data. Please try again.");
      if (result.confidence == null) {
        result.confidence = "medium";
        result.confidence_reasons = ["No matching product found in Open Food Facts — these values were read directly off the packaging by the AI rather than pulled from a database, so double-check against the printed label if precision matters."];
      }
      return res.status(200).json(result);
    }

    // ---- Case B: homemade / restaurant food ----
    const result = await buildResultForHomemade(triage, image, nvidiaKey);
    if (!result.food_name || !result.calories) throw new Error("Incomplete data. Please try again.");
    return res.status(200).json(result);

  } catch (err) {
    console.error("NutriScan error:", err.message);

    const isQuota = /quota|rate.?limit|resource_exhausted/i.test(err.message || "") || err.status === 429;
    const isTimeout = err.name === "AbortError" || /aborted|timed out/i.test(err.message || "");
    const friendlyMessage = isQuota
      ? `Free-tier limit reached.${err.message.match(/Try again.*/)?.[0] ? " " + err.message.match(/Try again.*/)[0] : " Please try again shortly."}`
      : isTimeout
      ? "The model is responding slowly right now. Please try again in a moment."
      : (err.message || "Analysis failed. Please try again.");

    return res.status(500).json({ error: friendlyMessage });
  }
};
