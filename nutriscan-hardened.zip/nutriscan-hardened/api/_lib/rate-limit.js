// ─────────────────────────────────────────────────────────────────────────
// Rate limiting (OWASP API4:2023 - Unrestricted Resource Consumption)
//
// Lightweight in-memory sliding-window limiter keyed by client identity
// (IP address, optionally combined with a per-user token/header if the
// app adds auth later). This is intentionally dependency-free so it
// works in any Node/Vercel serverless function without extra infra.
//
// IMPORTANT CAVEAT FOR SERVERLESS DEPLOYMENTS:
// Vercel functions are stateless and may run on different instances
// between invocations, so this in-memory store is a best-effort,
// per-instance limiter — it meaningfully slows down abuse and stops
// naive scripted flooding, but it is NOT a substitute for an edge/
// platform-level limiter for strict guarantees under high concurrency.
// For production-grade, multi-instance-consistent limits, back this
// with a shared store (Redis / Vercel KV / Upstash) — swap the
// `store` implementation below for one backed by that service; the
// public `checkRateLimit()` API does not need to change.
// ─────────────────────────────────────────────────────────────────────────

"use strict";

// key -> { count, windowStart }
const store = new Map();

// Periodically sweep expired entries so the Map doesn't grow unbounded
// on a long-lived warm serverless instance.
const SWEEP_INTERVAL_MS = 5 * 60 * 1000;
let lastSweep = Date.now();
function sweep(now) {
  if (now - lastSweep < SWEEP_INTERVAL_MS) return;
  lastSweep = now;
  for (const [key, entry] of store.entries()) {
    if (now - entry.windowStart > entry.windowMs) store.delete(key);
  }
}

/**
 * Extract the best-effort client IP from a Vercel/Node request object.
 * Vercel sits behind a trusted proxy that sets x-forwarded-for, so we
 * trust the first hop of that header; falls back to the socket address
 * for local/dev usage.
 */
function getClientIp(req) {
  const xff = req.headers["x-forwarded-for"];
  if (typeof xff === "string" && xff.length) {
    return xff.split(",")[0].trim();
  }
  return req.socket?.remoteAddress || "unknown";
}

/**
 * Check + record a request against a rate limit bucket.
 *
 * @param {string} key - unique bucket key, e.g. `${route}:${ip}`
 * @param {object} opts
 * @param {number} opts.limit - max requests allowed per window
 * @param {number} opts.windowMs - window size in milliseconds
 * @returns {{ allowed: boolean, remaining: number, retryAfterSeconds: number, limit: number }}
 */
function checkRateLimit(key, { limit, windowMs }) {
  const now = Date.now();
  sweep(now);

  let entry = store.get(key);
  if (!entry || now - entry.windowStart >= windowMs) {
    entry = { count: 0, windowStart: now, windowMs };
    store.set(key, entry);
  }

  entry.count += 1;
  const allowed = entry.count <= limit;
  const remaining = Math.max(0, limit - entry.count);
  const retryAfterSeconds = Math.ceil((entry.windowStart + windowMs - now) / 1000);

  return { allowed, remaining, retryAfterSeconds: Math.max(1, retryAfterSeconds), limit };
}

/**
 * Express/Vercel-style middleware helper: applies a rate limit to a
 * request, sends a standard 429 response (with Retry-After and
 * RateLimit-* headers per the IETF draft convention) when exceeded,
 * and returns whether the caller should continue handling the request.
 *
 * Usage inside a handler:
 *   if (!applyRateLimit(req, res, { routeName: "analyse", limit: 20, windowMs: 60_000 })) return;
 */
function applyRateLimit(req, res, { routeName, limit, windowMs, extraKey = "" }) {
  const ip = getClientIp(req);
  const key = `${routeName}:${ip}:${extraKey}`;
  const result = checkRateLimit(key, { limit, windowMs });

  // Always surface rate-limit state to well-behaved clients, even when
  // allowed, so they can self-throttle before hitting the limit.
  res.setHeader("RateLimit-Limit", String(result.limit));
  res.setHeader("RateLimit-Remaining", String(result.remaining));
  res.setHeader("RateLimit-Reset", String(result.retryAfterSeconds));

  if (!result.allowed) {
    res.setHeader("Retry-After", String(result.retryAfterSeconds));
    res.status(429).json({
      error: `Too many requests. Please slow down and try again in ${result.retryAfterSeconds} second(s).`
    });
    return false;
  }
  return true;
}

module.exports = { checkRateLimit, applyRateLimit, getClientIp };
