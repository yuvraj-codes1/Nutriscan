// ─────────────────────────────────────────────────────────────────────────
// Input validation & sanitization (OWASP API3:2023 - Broken Object
// Property Level Authorization / Excessive Data Exposure, and
// ASVS 5.1 - Input Validation)
//
// Small, dependency-free schema validator tailored to this app's needs:
//   - strict type checks
//   - length limits on strings
//   - allow-lists for enum-like fields
//   - rejection of unexpected/extra top-level fields ("reject unknown")
//   - dedicated base64-image validator (format, size, magic-byte sniff)
//
// Kept intentionally small and explicit rather than pulling in a schema
// library, since the request surface here is a single, simple shape.
// ─────────────────────────────────────────────────────────────────────────

"use strict";

class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = "ValidationError";
    this.statusCode = 400;
  }
}

// Reasonable ceiling for an uploaded/compressed food photo. The client
// already compresses images client-side, but the server must not trust
// that — this cap protects memory, the outbound request to the VLM
// (which is billed per call), and general DoS resistance.
const MAX_IMAGE_BASE64_CHARS = 8 * 1024 * 1024; // ~8MB of base64 text (~6MB raw)
const MIN_IMAGE_BASE64_CHARS = 100; // reject empty/near-empty payloads

// Magic bytes for the image formats we actually accept. Sniffing the
// decoded header rather than trusting a client-supplied mime type stops
// someone from sending an arbitrary file re-labelled as an image.
const IMAGE_SIGNATURES = [
  { format: "jpeg", bytes: [0xff, 0xd8, 0xff] },
  { format: "png", bytes: [0x89, 0x50, 0x4e, 0x47] },
  { format: "webp", bytes: [0x52, 0x49, 0x46, 0x46] } // "RIFF" (WebP container)
];

function looksLikeBase64(str) {
  // Standard base64 alphabet, optional padding, no whitespace/control chars.
  return /^[A-Za-z0-9+/]+={0,2}$/.test(str);
}

/**
 * Validate that a string is well-formed base64 image data of an
 * accepted format and within size limits. Accepts either a raw base64
 * string or a data: URL and normalizes to raw base64.
 *
 * @throws {ValidationError}
 * @returns {string} normalized raw base64 (no data: prefix)
 */
function validateImageBase64(value, fieldName = "image") {
  if (typeof value !== "string") {
    throw new ValidationError(`${fieldName} must be a string`);
  }

  let raw = value.trim();

  // Strip a data: URL prefix if present (e.g. "data:image/jpeg;base64,...")
  const dataUrlMatch = /^data:image\/(jpeg|jpg|png|webp);base64,(.+)$/i.exec(raw);
  if (dataUrlMatch) {
    raw = dataUrlMatch[2];
  }

  if (raw.length < MIN_IMAGE_BASE64_CHARS) {
    throw new ValidationError(`${fieldName} is empty or too small to be a valid image`);
  }
  if (raw.length > MAX_IMAGE_BASE64_CHARS) {
    throw new ValidationError(
      `${fieldName} is too large. Please use a smaller/more compressed image (max ~6MB).`
    );
  }
  if (!looksLikeBase64(raw)) {
    throw new ValidationError(`${fieldName} is not valid base64-encoded data`);
  }

  // Decode just the first few bytes to sniff the real file type rather
  // than trusting any client-declared mime type. Decoding a small prefix
  // is cheap even for large payloads.
  let headerBuf;
  try {
    headerBuf = Buffer.from(raw.slice(0, 32), "base64");
  } catch {
    throw new ValidationError(`${fieldName} could not be decoded as base64`);
  }

  const matchesKnownFormat = IMAGE_SIGNATURES.some(({ bytes }) =>
    bytes.every((b, i) => headerBuf[i] === b)
  );
  if (!matchesKnownFormat) {
    throw new ValidationError(
      `${fieldName} does not look like a supported image format (JPEG, PNG, or WebP)`
    );
  }

  return raw;
}

/**
 * Validate a plain string field: type, trimmed length bounds, and
 * optional character allow-list pattern.
 */
function validateString(value, { fieldName, minLength = 0, maxLength = 200, pattern = null, required = true }) {
  if (value == null || value === "") {
    if (required) throw new ValidationError(`${fieldName} is required`);
    return null;
  }
  if (typeof value !== "string") {
    throw new ValidationError(`${fieldName} must be a string`);
  }
  const trimmed = value.trim();
  if (trimmed.length < minLength) {
    throw new ValidationError(`${fieldName} is too short`);
  }
  if (trimmed.length > maxLength) {
    throw new ValidationError(`${fieldName} must be at most ${maxLength} characters`);
  }
  if (pattern && !pattern.test(trimmed)) {
    throw new ValidationError(`${fieldName} contains invalid characters`);
  }
  return trimmed;
}

/**
 * Reject any request body that isn't a plain object, or that contains
 * keys outside the provided allow-list. This is the "reject unexpected
 * fields" control — it stops mass-assignment-style payloads and keeps
 * the request shape exactly what the handler expects.
 */
function assertNoUnexpectedFields(body, allowedFields, contextName = "request body") {
  if (typeof body !== "object" || body === null || Array.isArray(body)) {
    throw new ValidationError(`${contextName} must be a JSON object`);
  }
  const extra = Object.keys(body).filter(k => !allowedFields.includes(k));
  if (extra.length) {
    throw new ValidationError(
      `${contextName} contains unexpected field(s): ${extra.join(", ")}`
    );
  }
}

module.exports = {
  ValidationError,
  validateImageBase64,
  validateString,
  assertNoUnexpectedFields,
  MAX_IMAGE_BASE64_CHARS
};
